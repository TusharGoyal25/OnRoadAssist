import { Component, OnInit } from '@angular/core';
import { RegisterSeekerService } from './register-seeker.service';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms/src/model';
import { PasswordValidator } from './password.validator';
import { PhoneNumberValidator } from './phonenumber.validator';

@Component({
  selector: 'app-regseeker',
  templateUrl: './regseeker.component.html',
  styleUrls: ['./regseeker.component.css']
})
export class RegseekerComponent implements OnInit {

  constructor(public service:RegisterSeekerService,public fb:FormBuilder,public router:Router) { }
  successId:string
  emailId
  userName
  mobile
  showForm=true
  pass
  answer
  flag
  errorMessage:string
  data
  registrationSeekerForm:FormGroup
  isPass
  showPass()
  {
   
    var pass=document.getElementById("passField")
    if(pass.getAttribute("type")=="password")
    {
      this.isPass=false;
      pass.setAttribute("type","text")
    }
    else if(pass.getAttribute("type")=="text")
    {
      this.isPass=true;
      pass.setAttribute("type","password")
    }
  }
  registerSeeker()
  {
    this.successId=null;
    this.errorMessage=null;
    this.service.registerPost(this.registrationSeekerForm.value)
    .then(response=>{this.successId=response,this.flag=1,this.showForm=false})
    .catch(error=>this.errorMessage="Account Already Exist. Try Logging In!")
    if(this.flag==1)
    {
      this.router.navigate(["helpSeeker"]);
    }
   
  }
  loginSeekerRedirect()
  {
    this.router.navigate(["helpSeeker"]);
  }

  ngOnInit() {
    console.log(this.router.url)
    this.isPass=true;
    this.registrationSeekerForm=this.fb.group({
      name:['',[Validators.required,Validators.pattern("[A-Z][a-zA-Z][^0-9#&<>\"~;$^%{}?]{1,50}[^ ]{0,}")]],
      password:['',[Validators.required,Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(.{8,32}$)")]],
      confPassword:['',[Validators.required]],
      userId:['',[Validators.required,Validators.pattern("[^0-9].*\\.com"),Validators.email]],
      phoneNumber:['',[Validators.required,Validators.pattern("[5-9][0-9]{9}"),PhoneNumberValidator.noRepeat]],
      question:['',[Validators.required]],
      answer:['',[Validators.required,Validators.pattern("[A-Z][a-zA-Z][^0-9#&<>\"~;$^%{}?]{1,50}[^ ]{0,}")]],
    },{validator:PasswordValidator.checkPass})
  }
  }