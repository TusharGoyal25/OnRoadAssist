import { Component } from '@angular/core';
import { Router } from "@angular/router";
declare var Swal:any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent { 


  constructor(public router:Router) {

    this.router.navigate(['home']);

  }
  startScreen()
  {
    if(sessionStorage.length>0 || localStorage.length>0)
    {
       Swal.fire({
        title: 'Sure to Go Back?',
        text: "All your Unsaved Data will be lost!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText:
        '<i class="fa fa-thumbs-up"></i> Yep',
      confirmButtonAriaLabel: 'Thumbs up, great!',
      cancelButtonText:
        '<i class="fa fa-thumbs-down"></i> Nop',
      cancelButtonAriaLabel: 'Thumbs down',
      }).then((result) => {
        if (result.value) {
          localStorage.clear();
          sessionStorage.clear();
          this.router.navigate(['home']);
        }
      })
    }
  
    else
    {
      localStorage.clear();
      sessionStorage.clear();
      this.router.navigate(['home']);
    }
  }
  goHome()
  {
    if(sessionStorage.length>0 || localStorage.length>0)
    {
          if(sessionStorage.getItem("userType")=="seeker")
          {
            this.router.navigate(['profileSeeker']);
          }
          if(sessionStorage.getItem("userType")=="provider")
          {
            this.router.navigate(['profileProvider']);
          }
    }
      //  Swal.fire({
      //   title: 'Sure to Go Back?',
      //   text: "All your Unsaved Data will be lost!",
      //   type: 'warning',
      //   showCancelButton: true,
      //   confirmButtonColor: '#3085d6',
      //   cancelButtonColor: '#d33',
      //   confirmButtonText:
      //   '<i class="fa fa-thumbs-up"></i> Yep',
      // confirmButtonAriaLabel: 'Thumbs up, great!',
      // cancelButtonText:
      //   '<i class="fa fa-thumbs-down"></i> Nop',
      // cancelButtonAriaLabel: 'Thumbs down',
      // }).then((result) => {
      //   if (result.value) {
      //     localStorage.clear();
      //     sessionStorage.clear();
      //     this.router.navigate(['home']);
      //   }
      // })
    

    else
    {

             Swal.fire({
        title: 'Sure to Go Back?',
        text: "All your Unsaved Data will be lost!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText:
        '<i class="fa fa-thumbs-up"></i> Yep',
      confirmButtonAriaLabel: 'Thumbs up, great!',
      cancelButtonText:
        '<i class="fa fa-thumbs-down"></i> Nop',
      cancelButtonAriaLabel: 'Thumbs down',
      }).then((result) => {
        if (result.value) {
          localStorage.clear();
          sessionStorage.clear();
          this.router.navigate(['home']);
        }
      })

      // localStorage.clear();
      // sessionStorage.clear();
      // this.router.navigate(['home']);
    }
  }

  myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }

}