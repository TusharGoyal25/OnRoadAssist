
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpModule } from "@angular/http";

import { HelpSeekerComponent } from './help-seeker/help-seeker.component';
import { HelpProviderComponent } from './help-provider/help-provider.component';
import { HelpSeekerLoginService } from './help-seeker/help-seeker-login.service';
import { HomePageComponent } from './home-page/home-page.component';
import { RegseekerComponent } from './regseeker/regseeker.component';
import { RegisterSeekerService } from './regseeker/register-seeker.service';
import { ProfileSeekerComponent } from './profile-seeker/profile-seeker.component';
import { ProfileProviderComponent } from './profile-provider/profile-provider.component';
import { RegproviderComponent } from './regprovider/regprovider.component';
import { HelpProviderLoginService } from './help-provider/help-provider-login.service';
import { RegisterProviderService } from './regprovider/register-provider.service';
import {MapComponent } from './map/map.component';
import { GetHelpSeekerComponent } from './get-help-seeker/get-help-seeker.component';
import { GetHelpSeekerService } from './get-help-seeker/get-help-seeker.service';
import{ PasswordResetComponent} from './password-reset/password-reset.component';
import { PasswordResetService } from './password-reset/password-reset.service';
import { UpdatephnoComponent } from './updatephno/updatephno.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { UpdateNameComponent } from './update-name/update-name.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { UpdatePhoneService } from './updatephno/update-phone.service';
import { ResetPasswordService } from './resetpassword/reset-password.service';
import { UpdateNameService } from './update-name/update-name.service';
import { SliderComponent } from './slider/slider.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ProfileproviderService } from './profile-provider/profileprovider.service';
import { ProviderService } from './profile-provider/provider.service';
import { LocationRGeocoderPipe } from './profile-provider/location-rgeocoder.pipe';
import { SeekerService } from './profile-seeker/seeker.service';
import { PasswordStrengthPipe } from './regseeker/password-strength.pipe';
import { ProfileServicingComponent } from './profile-servicing/profile-servicing.component';
import { ProviderServicingService } from './profile-servicing/provider-servicing.service';
import { SeekerServicingComponent } from './seeker-servicing/seeker-servicing.component';
import { SeekerServicingService } from './seeker-servicing/seeker-servicing.service';
import { PreviousAvailedComponent } from './previous-availed/previous-availed.component';
import { PreviousAvailedService } from './previous-availed/previous-availed.service';
import { FeedbackFormComponent } from './feedback-form/feedback-form.component';
import { FeedbackService } from './feedback-form/feedback.service';

@NgModule({
  declarations: [
    AppComponent,


    HelpSeekerComponent,
    HelpProviderComponent,
    HomePageComponent,
    RegseekerComponent,
    ProfileSeekerComponent,
    ProfileProviderComponent,
    RegproviderComponent,
    PasswordResetComponent,
    MapComponent,
    GetHelpSeekerComponent,
    UpdatephnoComponent,
    ResetpasswordComponent,
    UpdateNameComponent,
    UpdateDetailsComponent,
    SliderComponent,
    AboutUsComponent,
    LocationRGeocoderPipe,
    PasswordStrengthPipe,
    ProfileServicingComponent,
    SeekerServicingComponent,
    PreviousAvailedComponent,
    FeedbackFormComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule
  ],
  providers: [HelpSeekerLoginService,FeedbackService,PreviousAvailedService,SeekerServicingService,ProviderServicingService,SeekerService,PasswordResetService,RegisterSeekerService,HelpProviderLoginService,GetHelpSeekerService,RegisterProviderService,UpdatePhoneService,ResetPasswordService,UpdateNameService,ProviderService],
  bootstrap: [AppComponent]
})
export class AppModule { }
