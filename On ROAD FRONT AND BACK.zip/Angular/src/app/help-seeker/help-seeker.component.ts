import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { HelpSeekerLoginService } from './help-seeker-login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-help-seeker',
  templateUrl: './help-seeker.component.html',
  styleUrls: ['./help-seeker.component.css']
})
export class HelpSeekerComponent implements OnInit {
  

  isPass
  showPass()
  {
   
    var pass=document.getElementById("passField")
    if(pass.getAttribute("type")=="password")
    {
      this.isPass=false;
      pass.setAttribute("type","text")
    }
    else if(pass.getAttribute("type")=="text")
    {
      this.isPass=true;
      pass.setAttribute("type","password")
    }
  }
  constructor(public fb:FormBuilder,public service:HelpSeekerLoginService,public router: Router) { }
  errorMessage
  seekerLogin=this.fb.group({
    userId:['',[Validators.required,Validators.email,Validators.pattern("[^0-9].*\\.com"),Validators.minLength(10)]],
    password:['',[Validators.required,Validators.minLength(8)]]
    
  })
  loginSeeker()
  {
    this.errorMessage=null
    this.service.loginPost(this.seekerLogin.value)
    .then(response=>{sessionStorage.setItem("userId",response.userId),
    sessionStorage.setItem("userName",response.name),
    localStorage.setItem("active","true"),
    sessionStorage.setItem("loggedIn","true"),
    sessionStorage.setItem("userType","seeker"),
    sessionStorage.setItem("seekerDetails",JSON.stringify(response))
    this.router.navigate(['profileSeeker'])})
    .catch(error=>this.errorMessage=error.message)
  
  }
  seekerRegRedirect()
  {
    this.router.navigate(['registerSeeker']);
  }
  resetPassword()
  {
    sessionStorage.setItem("userType","seeker");
    this.router.navigate(['passwordReset']);
  }

  ngOnInit() {
  this.isPass=true;
  sessionStorage.clear()
  }

}