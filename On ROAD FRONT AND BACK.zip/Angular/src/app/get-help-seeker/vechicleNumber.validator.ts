import { AbstractControl } from "@angular/forms";


export class VechicleNumberValidator {
    static noRepeat(control: AbstractControl) {
        let value:string = ""+control.value;
        //console.log(value);
        if(value.slice(-4,).match("[0]{4}")){
            return {'noRepeat' : true}
        }
        return null;
    }

}