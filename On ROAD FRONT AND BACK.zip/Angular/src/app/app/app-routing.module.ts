import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HelpSeekerComponent } from './help-seeker/help-seeker.component';
import { HelpProviderComponent } from './help-provider/help-provider.component';
import { HomePageComponent } from './home-page/home-page.component';
import { RegseekerComponent } from './regseeker/regseeker.component';
import { ProfileSeekerComponent } from './profile-seeker/profile-seeker.component';
import { ProfileProviderComponent } from './profile-provider/profile-provider.component';
import { RegproviderComponent } from './regprovider/regprovider.component';
import { MapComponent } from './map/map.component';
import { GetHelpSeekerComponent } from './get-help-seeker/get-help-seeker.component';
import { PasswordResetComponent } from './password-reset/password-reset.component';
import { UpdatephnoComponent } from './updatephno/updatephno.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { UpdateNameComponent } from './update-name/update-name.component';
import { SliderComponent } from './slider/slider.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ProfileServicingComponent } from './profile-servicing/profile-servicing.component';
import { SeekerServicingComponent } from './seeker-servicing/seeker-servicing.component';
import { PreviousAvailedComponent } from './previous-availed/previous-availed.component';
import { FeedbackFormComponent } from './feedback-form/feedback-form.component';


const routes: Routes = [

 
  {path:'home',component:HomePageComponent },
  {path:'helpSeeker',component:HelpSeekerComponent},
  {path:'helpProvider',component:HelpProviderComponent},
  {path:'registerSeeker',component:RegseekerComponent},
  {path:'profileSeeker',component:ProfileSeekerComponent},
  {path:'profileProvider',component:ProfileProviderComponent},
  {path:'registerProvider',component:RegproviderComponent},
  {path:'map',component:MapComponent},
  {path:'passwordReset',component:PasswordResetComponent },
  {path:'getHelpSeeker',component:GetHelpSeekerComponent},
  {path:'updatephno',component:UpdatephnoComponent},
  {path:'updateDetails',component:UpdateDetailsComponent},
  {path:'resetPassword',component:ResetpasswordComponent},
  {path:'updateName',component:UpdateNameComponent},
 {path:'slider',component:SliderComponent},
 {path:'getHelpProvider',component:ProfileProviderComponent},
 {path:'aboutus',component:AboutUsComponent},
 {path:'providerServicing',component:ProfileServicingComponent},
 {path:'seekerServicing',component:SeekerServicingComponent},
  {path:'previousAvailed',component:PreviousAvailedComponent },
   {path:'feedback',component:FeedbackFormComponent }
  // {path:'loginSeeker',component:HelpSeekerComponent},
  // {path:'loginProvider',component:HelpProviderComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
