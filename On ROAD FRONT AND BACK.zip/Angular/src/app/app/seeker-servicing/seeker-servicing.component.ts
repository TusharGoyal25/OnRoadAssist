import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SeekerServicingService } from './seeker-servicing.service';

@Component({
  selector: 'app-seeker-servicing',
  templateUrl: './seeker-servicing.component.html',
  styleUrls: ['./seeker-servicing.component.css']
})
export class SeekerServicingComponent implements OnInit {

  constructor(public routes:Router,public service:SeekerServicingService) { }
  proLat
  proLon
  seekLat
  seekLon
  proLocation
  provider
  seeker
  seekerRequest
  proAddress
  seekAddress
  distanceToTravel
  arrivalTime
  errorMesage
  travelCharge
  totalAmount
  serviceCost


  ngOnInit() {
    let resp=""
    this.proLat=""
    this.proLon=""
    let proLatLon=""
    this.arrivalTime=0
    this.serviceCost=null;
    this.seekerRequest=JSON.parse(sessionStorage.getItem("seekerRequest"))
    this.provider=JSON.parse(sessionStorage.getItem("providerDetails"))
    this.seeker=JSON.parse(sessionStorage.getItem("seekerDetails"))
    this.seekAddress=JSON.parse(sessionStorage.getItem("seekerAddress"))
    this.service.getProviderlocation(this.provider.userId)
    .then(response=>{proLatLon=response.location})
    .catch(error=>this.errorMesage=error);
    // this.seekLat=sessionStorage.getItem("latitude")
    // this.seekLon=sessionStorage.getItem("longitude")
    // this.service.getLocationAddress(this.proLat,this.proLon)
    // .then(response=>{this.proAddress=response.display_name})
    // .catch(error=>{console.log("Error in Decrypting Location")})
    this.service.getServiceCost(this.seekerRequest.requestId)
    .then(response=>{this.serviceCost=response,this.arrivalTime=((parseFloat(response.distanceTravelled)/50)*60)+""})
    .catch(error=>{console.log("Unable to fetch Cost details")})

  }

  redirectBack()
  {
    window.history.back()
  }
}
