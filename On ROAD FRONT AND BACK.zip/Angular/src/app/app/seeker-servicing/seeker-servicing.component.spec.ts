import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeekerServicingComponent } from './seeker-servicing.component';

describe('SeekerServicingComponent', () => {
  let component: SeekerServicingComponent;
  let fixture: ComponentFixture<SeekerServicingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeekerServicingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeekerServicingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
