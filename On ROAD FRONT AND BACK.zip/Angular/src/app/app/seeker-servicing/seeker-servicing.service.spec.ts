import { TestBed, inject } from '@angular/core/testing';

import { SeekerServicingService } from './seeker-servicing.service';

describe('SeekerServicingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SeekerServicingService]
    });
  });

  it('should be created', inject([SeekerServicingService], (service: SeekerServicingService) => {
    expect(service).toBeTruthy();
  }));
});
