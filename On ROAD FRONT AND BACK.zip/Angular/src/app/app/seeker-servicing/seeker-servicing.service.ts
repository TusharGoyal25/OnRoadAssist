import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class SeekerServicingService {

  constructor(public http:Http) { }
  getLocationAddress(lat,lon):Promise<any>
  {
    return this.http.get("https://us1.locationiq.com/v1/reverse.php?key=pk.ed65f4a4ccbcf5b44713d68208afae10&lat="+lat+"&lon="+lon+"&format=json")
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  getProviderlocation(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/get_provider_location",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  getServiceCost(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/getServiceCostDetails",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  handleError(error){
    return Promise.reject(error.json());
  }
}