import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FeedbackService } from './feedback.service';

@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.css']
})
export class FeedbackFormComponent implements OnInit {
  feedbackForm
  showForm
  loggedin
  constructor(public fb:FormBuilder,public service:FeedbackService) { }

  feedbackSave()
{
        this.service.feedbackSavePost(this.feedbackForm.value)
      .then(response =>{ this.showForm=false})
      .catch(error =>{console.log("Error Occured")})
}

  ngOnInit() {

    this.showForm=true
    this.loggedin=false;
    this.feedbackForm=this.fb.group({
      userName:['',[Validators.required,Validators.pattern("[A-Z][a-zA-Z][^0-9#&<>\"~;$^%{}?]{1,50}[^ ]")]],
      email:['',[Validators.required,Validators.email]],
      easeOfAccess:['',[Validators.required]],
      bestFeature:['',[Validators.required]],
      rating:['',[Validators.required]],
      improve:['',[Validators.required]],
      recommendation:['',[Validators.required]],
      other:['',[Validators.required]]
  })

  if(sessionStorage.getItem("loggedIn")=="true")
  {
    this.loggedin=true;
    this.feedbackForm.controls.userName.setValue(sessionStorage.getItem("userName"));
    this.feedbackForm.controls.email.setValue(sessionStorage.getItem("userId"));
  }
}


}
