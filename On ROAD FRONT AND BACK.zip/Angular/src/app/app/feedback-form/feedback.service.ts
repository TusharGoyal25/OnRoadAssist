import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class FeedbackService {

  constructor(public http:Http) { }

  feedbackSavePost(data): Promise<any> {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/saveFeedback", data)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError)
  }

  handleError(error) {
    return Promise.reject(error.json());
  }
}
