import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class RegisterSeekerService {

  constructor(public http:Http) { }

  registerPost(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/addSeeker",data)
    .toPromise()
    .then(response=>response.text())
    .catch(this.handleError)
  }

  handleError(error){
    return Promise.reject(error.text());
  }

}
