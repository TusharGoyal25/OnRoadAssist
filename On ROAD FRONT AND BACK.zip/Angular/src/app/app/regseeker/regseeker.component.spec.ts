import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegseekerComponent } from './regseeker.component';

describe('RegseekerComponent', () => {
  let component: RegseekerComponent;
  let fixture: ComponentFixture<RegseekerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegseekerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegseekerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
