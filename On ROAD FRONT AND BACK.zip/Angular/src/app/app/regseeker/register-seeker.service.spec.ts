import { TestBed, inject } from '@angular/core/testing';

import { RegisterSeekerService } from './register-seeker.service';

describe('RegisterSeekerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RegisterSeekerService]
    });
  });

  it('should be created', inject([RegisterSeekerService], (service: RegisterSeekerService) => {
    expect(service).toBeTruthy();
  }));
});
