import { LocationRGeocoderPipe } from './location-rgeocoder.pipe';

describe('LocationRGeocoderPipe', () => {
  it('create an instance', () => {
    const pipe = new LocationRGeocoderPipe();
    expect(pipe).toBeTruthy();
  });
});
