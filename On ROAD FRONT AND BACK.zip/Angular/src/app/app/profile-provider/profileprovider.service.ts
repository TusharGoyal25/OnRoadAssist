import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class ProfileproviderService {

  constructor(private http:Http) { }

  getAssistRequestDetails():Promise<any>
  {
    return this.http.get("http://localhost:3333/UDAI_BackEnd/ProjectAPI/getAssistRequestDetails")
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

 getLocationAddress():Promise<any>
 {
   return this.http.get("https://us1.locationiq.com/v1/reverse.php?key=pk.ed65f4a4ccbcf5b44713d68208afae10&lat=-37.870662&lon=144.9803321&format=json")
   .toPromise()
   .then(response=>response.json())
   .catch(this.handleError)
 }

  updateStatus(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/setStatus",data)
    .toPromise()
    .then(response=>response.text())
    .catch(this.handleError)
  }

  handleError(error){
    return Promise.reject(error.json());
  }

}





