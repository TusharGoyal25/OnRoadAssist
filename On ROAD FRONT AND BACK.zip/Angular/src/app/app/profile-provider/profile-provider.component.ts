import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { ProviderService} from './provider.service';
import { Validators } from '@angular/forms';
declare var Swal:any;
@Component({
  selector: 'app-profile-provider',
  templateUrl: './profile-provider.component.html',
  styleUrls: ['./profile-provider.component.css']
})
export class ProfileProviderComponent implements OnInit {
  userId
  noData
  mapCanvasInline
  mapCanvas
  isServicing
  flag=0
  distanceToTravel
  travelCharge
  totalAmount
  providerAddress
  addressMessage
  seekerRequest
  address
  userName
  message
  successMessage
  errorMessage
  activeButton
  locData
  status
  indLoc
  locationValue
  seeker
  showLocation=false
  requestData
  data
  indTemp=null
  isModify
  responseRequest
  ModifyCostForm
  dataCost
  statusFlag:boolean=false;
  constructor(public router:Router,public fb:FormBuilder,public service:ProviderService) { }

  
  previousAvailed()
  {
    sessionStorage.setItem("userType","provider")
    this.router.navigate(["previousAvailed"])
  }

   
  ngOnInit() {
 
    this.isServicing=false
    this.addressMessage=null
    this.mapCanvas=document.getElementById("gmap_canvas")
    this.ModifyCostForm=this.fb.group({
      costMod:['',[Validators.required,Validators.min(1)]]
    })
    this.isModify=false
    this.activeButton=document.getElementById("activeStatus")
    this.userName=sessionStorage.getItem("userName")
    this.userId=sessionStorage.getItem("userId")
    if(sessionStorage.length<1)
    {
      this.router.navigate(['helpProvider']);
    }

    if (window.navigator && window.navigator.geolocation) {
      window.navigator.geolocation.getCurrentPosition(
          position => {
                  sessionStorage.setItem("location","true"),
                  sessionStorage.setItem("latitude",position.coords.latitude as any),
                  sessionStorage.setItem("longitude",position.coords.longitude as any)  ,
                  this.mapCanvas.setAttribute("src","https://maps.google.com/maps?q="+position.coords.latitude as any+"%2C"+position.coords.longitude as any+"&t=&z=13&ie=UTF8&iwloc=&output=embed"),                
                  this.service.getLocationAddress(position.coords.latitude,position.coords.longitude)
                  .then(response=>{this.providerAddress=response.display_name})
                  .catch(error=>{console.log(error),alert(error)})
                },

          error => {
              switch (error.code) {
                  case 1:
                      console.log('Permission Denied');
                      break;
                  case 2:
                      console.log('Position Unavailable');
                      break;
                  case 3:
                      console.log('Timeout');
                      break;
              }
          }
      );
  }

}

setlocValuManu(locManuValue)
{
 locManuValue=(locManuValue+"").replace(" ","")
 sessionStorage.setItem("latitude",(locManuValue+"").split(',')[0])
 sessionStorage.setItem("longitude",(locManuValue+"").split(',')[1])
//  console.log(sessionStorage.getItem("longitude"))
}

  statusChanged()
  {
      /*

      <<<<<<< SETTING LOCATION MANUALLY FOR TESTING >>>>>>>
    Comment below FUNCTION CALL  to use ORGINAL BROWSER VALUES

      */

////////////////////////////////////////////////////////////

this.setlocValuManu("12.374666, 76.594693");
    
////////////////////////////////////////////////////////////   

    this.showLocation=false
    if(this.activeButton.checked)
    {
      this.data={
        "providerId":sessionStorage.getItem("userId"),
        "status":"active"
      }
      this.locData={
        "providerId":sessionStorage.getItem("userId"),
        "location":sessionStorage.getItem("latitude")+"|"+sessionStorage.getItem("longitude")

      }

      // console.log(this.locData)
      this.service.updateStatus(this.data)
      .then(response=>{this.message=response,this.status=true,this.getAllRequests()})
      .catch(error=>this.errorMessage=error)
      this.service.setLocation(this.locData)
      .then(response=>{this.message=response})
      .catch(error=>this.errorMessage=error)
    }
    else
    {
      this.data={
        "providerId":sessionStorage.getItem("userId"),
        "status":"inactive"
      }
      this.service.updateStatus(this.data)
      .then(response=>{this.message=response,this.status=false})
      .catch(error=>this.errorMessage=error)
    }
  }
  setLocFlag(index)
  {
    this.showLocation=true
    this.indLoc=index
    if(this.indTemp!=index)
    {
      this.isModify=false
    }
  }

  loadSeekerLocation(request,index)
  {
    let desLat=request.location.split("|")[0]
    let desLon=request.location.split("|")[1]
    let orginLat=sessionStorage.getItem("latitude")
    let orginLon=sessionStorage.getItem("longitude")
    if(document.getElementById("map_location") && index==this.indLoc)
    {
      this.mapCanvasInline=document.getElementById("map_location")
      let desLat=request.location.split("|")[0]
      let desLon=request.location.split("|")[1]
      this.mapCanvasInline.setAttribute("src","https://maps.google.com/maps?q="+desLat+"%2C"+desLon+"&t=&z=13&ie=UTF8&iwloc=&output=embed")
      
      if(this.flag==0)
      {
      // this.locationValue=null
      this.service.getLocationAddress(desLat,desLon)
      .then(response=>{this.locationValue=response.display_name})
      .catch(error=>this.locationValue=null);
      var x = document.getElementById("snackbar");
      // Add the "show" class to DIV
      x.className = "show";
      // After 3 seconds, remove the show class from DIV
      setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
      this.flag+=1
      }
      //console.log(desLat +"  "+desLon)
     
    }
    return true
    //window.open("https://www.google.com/maps/dir/?api=1&origin="+orginLat+" "+orginLon+"&destination="+desLat+" "+desLon+"&travelmode=driving","_blank")
    // this.mapCanvasInline.setAttribute("src","https://www.google.com/maps/embed/v1/directions?origin=12.228144+76.584495&destination=12.361728+76.60011519999999&key=AIzaSyD7-8CMg92xjqQvIwlFVDVKMTCptSJGhyo")                
    //this.mapCanvasInline.setAttribute("src","https://www.google.com/maps/dir/?api=1&origin="+orginLat+" "+orginLong+"&destination="+latitude+" "+longitude+"&travelmode=bicycling")                
    // this.mapCanvasInline.setAttribute("src","https://maps.google.com/maps?q="+latitude+"%2C"+longitude+"&t=&z=13&ie=UTF8&iwloc=&output=embed")                
  
  }

  clear()
  {
    this.isModify=false;
    this.ModifyCostForm.controls.costMod.setValue("");
    // this.showLocation=false
  }
  getAllRequests()
  {
    let proData={
      "providerId":sessionStorage.getItem("userId"),
      "location":sessionStorage.getItem("latitude")+"|"+sessionStorage.getItem("longitude")
    }
      this.service.getAssistRequestDetails(proData)
      .then(response=>{this.requestData=response,this.checkStatus(response)})
      .catch(error=>{this.errorMessage=error,this.requestData=null,console.log("Error Occured, Please Login Again")})
  }
  checkStatus(response)
  {
    if(response.length==0)
    {
      this.noData=true;
    }
    else{
      this.noData=false;
    }
  }
  onModify(request,index)
  {
    this.indTemp=index
    this.responseRequest=request;
    this.isModify=true
    if(this.indLoc!=index)
    {
      this.showLocation=false
    }
  }

  updateCost(costMod)
  {
    if(costMod>0)
    {
      this.responseRequest.estimatedCost=costMod
      this.service.updateCostPost(this.responseRequest)
      .then(response=>{this.showUpdatedTable(response,this.responseRequest.requestId)})
      .catch(error=>{this.errorMessage=error,this.clear(),this.requestData=null,console.log("Error Occured")})
    }
  }
  showUpdatedTable(response,requestId)
  {
    for(let resp of response)
    {
      if(resp.requestId==requestId)
      {
        this.requestData=null
        this.requestData=resp
      }
    }
    this.clear();
  }
  updateDetails()
  {
    localStorage.setItem("userType","provider")
    this.router.navigate(["updateDetails"])
  }
  distance(lat1, lon1, lat2, lon2, unit = "K") {
    if ((lat1 == lat2) && (lon1 == lon2)) {
      return null;
    }
    else {
      var radlat1 = Math.PI * lat1 / 180;
      var radlat2 = Math.PI * lat2 / 180;
      var theta = lon1 - lon2;
      var radtheta = Math.PI * theta / 180;
      var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
      if (dist > 1) {
        dist = 1;
      }
      dist = Math.acos(dist);
      dist = dist * 180 / Math.PI;
      dist = dist * 60 * 1.1515;
      if (unit == "K") { dist = dist * 1.609344 }
      if (unit == "N") { dist = dist * 0.8684 }
      return dist;
    }
  }

  saveServiceCost(lat1, lon1, lat2, lon2)
  {
    let traChrgFinal="30"
    this.distanceToTravel = this.distance(lat1, lon1, lat2, lon2);
    if(this.distanceToTravel!=null)
      {
        this.travelCharge=3*this.distanceToTravel
        if(new Date().getHours()>=21 || new Date().getHours()<6)
        {
          this.travelCharge=5*this.distanceToTravel
        }
        if(+((''+this.travelCharge).substring(0,((''+this.travelCharge).indexOf('.')+3)))>30)
        {
          traChrgFinal=(''+this.travelCharge).substring(0,((''+this.travelCharge).indexOf('.')+3))
        }
        this.totalAmount=(+traChrgFinal)+(+this.seekerRequest.estimatedCost)
        this.distanceToTravel=this.distanceToTravel+'';
      
      }

     

    let serviceCost={
      "requestId":this.seekerRequest.requestId,
      "providerId":sessionStorage.getItem("userId"),
      "seekerId":this.seekerRequest.seekerId,
      "estimatedCost":this.seekerRequest.estimatedCost,
      "distanceTravelled":(''+this.distanceToTravel).substring(0,((''+this.distanceToTravel).indexOf('.')+3)),
      "travelCharge":traChrgFinal,
      "totalCost":(''+this.totalAmount).substring(0,((''+this.totalAmount).indexOf('.')+3))
    }
    this.service.saveServiceCost(serviceCost)
    .then(response=>{this.successMessage=response})
    .catch(error=>{console.log(error)});
  }
  
  redirectFeedback()
  {
    sessionStorage.setItem("loggedIn","true")
    this.router.navigate(["feedback"])

  }

  logout(data=1)
  {
    if(data==1)
    {
      Swal.fire({
        title: 'Sure to Logout?',
        text: "All Your Data Will be Lost",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'LogOut'
      }).then((result) => {
        if (result.value) {
          localStorage.clear();
          sessionStorage.clear();
          this.router.navigate(['helpProvider']);
        }
      })
    }
    else
    {
      localStorage.clear();
      sessionStorage.clear();
      alert("Sorry Some error occcured. Please Login Again")
      this.router.navigate(['helpProvider']);
    }
    
  }

  statusfunc()
  {
    this.statusFlag=!this.statusFlag
    this.statusChanged()
  }  

  onRespond(request)
  {
      this.seekerRequest=request
      this.addressMessage=null
      let setReqProData={
        "providerId":sessionStorage.getItem("userId"),
        "requestId":request.requestId
      };
      let setReqStatusData={
        "status":"inProgress",
        "requestId":request.requestId
      };
      let desLat=request.location.split("|")[0]
      let desLon=request.location.split("|")[1]
      let orginLat=sessionStorage.getItem("latitude")
      let orginLon=sessionStorage.getItem("longitude")
      this.service.getLocationAddress(desLat,desLon)
        .then(response=>{this.address=response.display_name})
        .catch(error=>{console.log(error),alert(error)});

      //CODE SHOULD BE CHANGED WITH AT MOST CARE

      this.service.updateProviderForService(setReqProData)
        .then(response=>{this.saveServiceCost(orginLat,orginLon,desLat,desLon),
                        this.service.updateServiceRequestStatus(setReqStatusData)
                           .then(responseStatus=>{
                                  this.service.getSeekerDetails(request.seekerId)
                                    .then(response=>{
                                              this.launch_toast(),
                                              setTimeout(()=>{
                                                    localStorage.setItem("seeker",JSON.stringify(response)),localStorage.setItem("address",JSON.stringify(this.address)),localStorage.setItem("request",JSON.stringify(request)),
                                                    window.open("https://www.google.com/maps/dir/?api=1&origin="+orginLat+","+orginLon+"&destination="+desLat+","+desLon+"&travelmode=driving","_blank"),
                                                    localStorage.setItem("directions","https://www.google.com/maps/dir/?api=1&origin="+orginLat+","+orginLon+"&destination="+desLat+","+desLon+"&travelmode=driving"),
                                                    sessionStorage.setItem("orginLat",orginLat),sessionStorage.setItem("orginLon",orginLon),
                                                    sessionStorage.setItem("desLat",desLat),sessionStorage.setItem("desLon",desLon),
                                                    this.router.navigate(["providerServicing"]);
                                              },5000)
                                      })
                                    .catch(error=>{console.log(error.message)})
                            })
                          .catch(error=>{console.log(error.message)})
            })
          .catch(error=>{console.log("Unable to Redirect Now. Please try again")})

          
      this.addressMessage="We are Feching Directions. Please Wait.."
        setTimeout(()=>{
      if(this.address==null)
      {
        this.addressMessage="We are Feching Directions. Please Wait.."
      }
      else
      {
        this.addressMessage="Customer is Near : "+this.address
      }},500);
      
      
     
        
}

launch_toast() {
  var x = document.getElementById("toast")
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
}
  
}
