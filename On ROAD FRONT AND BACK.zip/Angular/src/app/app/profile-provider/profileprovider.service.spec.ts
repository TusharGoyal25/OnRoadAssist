import { TestBed, inject } from '@angular/core/testing';

import { ProfileproviderService } from './profileprovider.service';

describe('ProfileproviderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProfileproviderService]
    });
  });

  it('should be created', inject([ProfileproviderService], (service: ProfileproviderService) => {
    expect(service).toBeTruthy();
  }));
});
