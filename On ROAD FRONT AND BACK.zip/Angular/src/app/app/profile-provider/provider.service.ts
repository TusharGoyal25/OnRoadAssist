import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class ProviderService {

  constructor(public http:Http) { }

  updateStatus(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/setStatus",data)
    .toPromise()
    .then(response=>response.text())
    .catch(this.handleError)
  }

  updateProviderForService(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/setProviderForService",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  updateServiceRequestStatus(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/setServiceRequestStatus",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }
  saveServiceCost(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/saveServiceCostDetails",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }
  getLocationAddress(lat,lon):Promise<any>
  {
    return this.http.get("https://us1.locationiq.com/v1/reverse.php?key=pk.ed65f4a4ccbcf5b44713d68208afae10&lat="+lat+"&lon="+lon+"&format=json")
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  getSeekerDetails(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/get_seeker_contact_details",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  getAssistRequestDetails(proData):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/getAssistRequestDetails",proData)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }
  updateCostPost(dataCost):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/modify_cost",dataCost)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }   
  
  setLocation(dataLoc):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/setProviderLocation",dataLoc)
    .toPromise()
    .then(response=>response.text())
    .catch(this.handleError)
  }

  handleError(error){
    return Promise.reject(error.json());
  }
}
