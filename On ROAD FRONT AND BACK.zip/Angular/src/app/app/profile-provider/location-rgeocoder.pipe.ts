import { Pipe, PipeTransform } from '@angular/core';
import { Http } from '@angular/http';
import { ProviderService } from './provider.service';

@Pipe({
  name: 'locationRGeocoder'
})
export class LocationRGeocoderPipe implements PipeTransform {

  constructor(public service:ProviderService){}
  transform(value: any, args?: any): any {
    var address=null
    var lat=value.split("|")[0]
    var lon=value.split("|")[1]
    console.log(lat+"   "+lon)
    return address

  }

}
