import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SeekerService } from './seeker.service';
declare let Swal: any;

@Component({
  selector: 'app-profile-seeker',
  templateUrl: './profile-seeker.component.html',
  styleUrls: ['./profile-seeker.component.css']
})
export class ProfileSeekerComponent implements OnInit {
  userId
  userName
  mapCanvas 
  seekerAddress=null
  constructor(public router:Router,public service:SeekerService) { }
  redirectFeedback()
  {
    sessionStorage.setItem("loggedIn","true")
    this.router.navigate(["feedback"])

  }


getHelp()
{
  if(sessionStorage.getItem("userName") &&
   sessionStorage.getItem("userId") &&
   sessionStorage.getItem("location") &&
   sessionStorage.getItem("latitude") &&
   sessionStorage.getItem("longitude"))
   {
    this.router.navigate(["getHelpSeeker"]) 
   }

}

previousAvailed()
{
  sessionStorage.setItem("userType","seeker")
  this.router.navigate(["previousAvailed"])
}
  ngOnInit() {

    this.mapCanvas=document.getElementById("gmap_canvas")
    this.userName=sessionStorage.getItem("userName")
    this.userId=sessionStorage.getItem("userId")
    if(sessionStorage.length<1)
    {
      this.router.navigate(['login']);
    }
    if (window.navigator && window.navigator.geolocation) {
      window.navigator.geolocation.getCurrentPosition(
          position => {
                  sessionStorage.setItem("userId",this.userId),
                  sessionStorage.setItem("location","true"),
                  sessionStorage.setItem("latitude",position.coords.latitude as any),
                  sessionStorage.setItem("longitude",position.coords.longitude as any),
                  // console.log(position),
                  this.mapCanvas.setAttribute("src","https://maps.google.com/maps?q="+position.coords.latitude as any+"%2C"+position.coords.longitude as any+"&t=&z=13&ie=UTF8&iwloc=&output=embed"),
                  this.service.getLocationAddress(position.coords.latitude,position.coords.longitude)
                  .then(response=>{this.seekerAddress=response.display_name,sessionStorage.setItem("seekerAddress",JSON.stringify(response.display_name))})
                  .catch(error=>{console.log(error),alert(error)})
          },

          error => {
              switch (error.code) {
                  case 1:
                      console.log('Permission Denied');
                      break;
                  case 2:
                      console.log('Position Unavailable');
                      break;
                  case 3:
                      console.log('Timeout');
                      break;
              }
          }
      );
  }


  }
  logout()
  {
    Swal.fire({
      title: 'Sure to Logout?',
      text: "All Your Data Will be Lost",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'LogOut'
    }).then((result) => {
      if (result.value) {
        localStorage.clear();
        sessionStorage.clear();
        this.router.navigate(['helpSeeker']);
      }
    })
  }

  updateDetails()
  {
    localStorage.setItem("userType","seeker")
    this.router.navigate(["updateDetails"])
  }

}


  

