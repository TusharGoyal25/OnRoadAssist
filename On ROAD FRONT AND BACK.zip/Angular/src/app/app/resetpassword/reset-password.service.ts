import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class ResetPasswordService {

  constructor(private http:Http) { }

  resetPasswordPost(data):Promise<any>
  {
    if(localStorage.getItem("userType")=="seeker")
    {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/seeker_reset_password",data)
    .toPromise()
    .then(response=>response.json() as any)
    .catch(this.handleError)
    }
    if(localStorage.getItem("userType")=="provider")
    {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/provider_reset_password",data)
    .toPromise()
    .then(response=>response.json() as any)
    .catch(this.handleError)
    }
    
  }

  handleError(error){
    return Promise.reject(error.json());
  }
}
