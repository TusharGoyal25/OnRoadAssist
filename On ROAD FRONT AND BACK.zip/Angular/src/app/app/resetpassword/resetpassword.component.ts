import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ResetPasswordService } from './reset-password.service';
import { Http } from '@angular/http';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { PasswordValidator } from './password.validator';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {

  constructor(private http:Http,private fb:FormBuilder,private service:ResetPasswordService) { }
  errorMessage;
  successMessage
  showForm
  resetPasswordValue
  userSessionId
  resetPasswordForm:FormGroup
  isPass
  showPass()
  {
   
    var pass=document.getElementById("passField")
    if(pass.getAttribute("type")=="password")
    {
      this.isPass=false;
      pass.setAttribute("type","text")
    }
    else if(pass.getAttribute("type")=="text")
    {
      this.isPass=true;
      pass.setAttribute("type","password")
    }
  }
  ngOnInit() {
    this.isPass=true;
    this.userSessionId=sessionStorage.getItem("userId");
    this.showForm=true
    this.resetPasswordForm=this.fb.group(
    {

      password:['',[Validators.required]],
      confNewPassword:['',[Validators.required]],
      userId:[''],
      newpassword:['',[Validators.required,Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(.{8,32}$)")]],
    },{validator:PasswordValidator.checkPass})

  }
  resetPassword()
  {
    this.errorMessage=null
    this.resetPasswordValue={
      "userId":sessionStorage.getItem("userId"),
      "password":this.resetPasswordForm.controls.password.value+"-"+this.resetPasswordForm.controls.newpassword.value
    }
    this.resetPasswordForm.controls.userId.setValue(this.userSessionId)
    this.service.resetPasswordPost(this.resetPasswordValue)
    .then(response=>{this.successMessage=response.message,this.showForm=false})
    .catch(error=>this.errorMessage=error.message)
  
  }

}
