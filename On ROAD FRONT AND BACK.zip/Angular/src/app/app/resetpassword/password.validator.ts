import { AbstractControl } from "@angular/forms";


export class PasswordValidator {
    static checkPass(AC: AbstractControl) {
        let password = AC.get('newpassword').value; // to get value in input tag
        let confirmPassword = AC.get('confNewPassword').value; // to get value in input tag
         if(password != confirmPassword) {
             AC.get('confNewPassword').setErrors( {checkPass: true} )
         } else {
             return null
         }
    }

}