import { TestBed, inject } from '@angular/core/testing';

import { GetHelpSeekerService } from './get-help-seeker.service';

describe('GetHelpSeekerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetHelpSeekerService]
    });
  });

  it('should be created', inject([GetHelpSeekerService], (service: GetHelpSeekerService) => {
    expect(service).toBeTruthy();
  }));
});
