import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class GetHelpSeekerService {

  constructor(public http: Http) { }

  getManfDataPost(data): Promise<any> {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/get_company_name", data)
      //return this.http.post("",data)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError)
  }

  getServiceProvider(data): Promise<any> {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/get_provider_contact_details", data)
      //return this.http.post("",data)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError)
  }

  getModelDataPost(data): Promise<any> {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/get_model_name", data)
      //return this.http.post("",data)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError)
  }

  getProblemDataPost(data): Promise<any> {
    console.log(data)
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/get_problem_name", data)
      //return this.http.post("",data)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError)
  }

  getEstimateCost(data1, data2): Promise<any> {
    //return this.http.get(""+data)
    // data1=data1+"/"+data2;
    return this.http.get("http://localhost:3333/UDAI_BackEnd/ProjectAPI/get_estimated_cost/?vehicleType=" + data1 + "&probType=" + data2)
      .toPromise()
      .then(response => response.text())
      .catch(this.handleErrorText)

  }

  sendAssistRequest(data): Promise<any> {
    //return this.http.get(""+data)
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/saveAssistRequest", data)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError)
  }

  getApprovedService(requestId)
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/getApprovedService", requestId)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError)
  }

  handleError(error) {
    // return Promise.reject(error.text());
    return Promise.reject(error.json());
  }

  handleErrorText(error) {
    return Promise.reject(error.text());
    //return Promise.reject(error.json());
  }

}
