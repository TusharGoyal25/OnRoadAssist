import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetHelpSeekerComponent } from './get-help-seeker.component';

describe('GetHelpSeekerComponent', () => {
  let component: GetHelpSeekerComponent;
  let fixture: ComponentFixture<GetHelpSeekerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetHelpSeekerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetHelpSeekerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
