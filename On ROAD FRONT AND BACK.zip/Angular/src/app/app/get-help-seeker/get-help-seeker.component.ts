import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { GetHelpSeekerService } from './get-help-seeker.service';

@Component({
  selector: 'app-get-help-seeker',
  templateUrl: './get-help-seeker.component.html',
  styleUrls: ['./get-help-seeker.component.css']
})
export class GetHelpSeekerComponent implements OnInit {

  manuf_data
  problem_data
  model_data
  timeOut
  token
  errorMessage
  successMessage
  estimate
  showFullForm
  vechId
  showLoading
  toastMessage = "Please Choose Correct Options to Continue"
  userId
  message
  location
  counter
  latitude
  longitude
  altitude
  othersValue
  accuracy
  speed
  vtype
  getSeekerHelpForm: FormGroup

  //Set the Seconds to wait (limit*3) seconds
  //You can Monitor this Count at Console.....

  limit=5

  
  constructor(public fb: FormBuilder, public router: Router, public service: GetHelpSeekerService) { }

  getManufData(vtype) {

    this.errorMessage = null
    this.successMessage = null
    this.estimate = null
    this.manuf_data = null
    this.model_data = null
    this.problem_data = null
    this.message = null
    this.getSeekerHelpForm.controls.vmanuf.setValue("")
    this.getSeekerHelpForm.controls.vmodel.setValue("")
    this.service.getManfDataPost(vtype)
      .then(response => this.manuf_data = response)
      .catch(error => this.errorMessage = error)
  }
  getModelData(manf) {
    this.errorMessage = null
    this.successMessage = null
    this.estimate = null
    this.vechId = null
    this.message = null
    this.model_data = null
    this.problem_data = null
    this.vtype = this.getSeekerHelpForm.controls.vtype.value;
    this.getSeekerHelpForm.controls.vmodel.setValue("")
    this.getSeekerHelpForm.controls.vehnum.setValue("")
    this.getSeekerHelpForm.controls.probdescr.setValue("")
    this.service.getModelDataPost(manf)
      .then(response => this.model_data = response)
      .catch(error => this.errorMessage = error)
  }

  getProblemData(vtype) {

    this.errorMessage = null
    this.successMessage = null
    this.estimate = null
    this.vechId = null
    this.message = null
    this.problem_data = null
    this.service.getProblemDataPost(vtype)
      .then(response => this.problem_data = response)
      .catch(error => this.errorMessage = error);




  }


  getEstimatedCost() {
    this.errorMessage = null
    this.successMessage = null

    this.estimate = null
    this.othersValue = null
    if (this.getSeekerHelpForm.controls.vproblem.value == "Other") {
      this.othersValue = "(Price may vary depending on the problem)"
    }
    else {
      this.othersValue = null
    }
    this.service.getEstimateCost(this.getSeekerHelpForm.controls.vtype.value, this.getSeekerHelpForm.controls.vproblem.value)
      .then(response => {
        this.estimate = response;
        this.getSeekerHelpForm.controls.estimatedCost.setValue(this.estimate);
        this.getSeekerHelpForm.controls.seekerId.setValue(this.userId);
        this.getSeekerHelpForm.controls.location.setValue(this.latitude + "|" + this.longitude);
      }
      )
      .catch(error => this.errorMessage = error.message)

  }

  sendAssistRequest() {
    this.errorMessage = null
    this.successMessage = null
    this.getSeekerHelpForm.controls.status.setValue("open")
    this.getSeekerHelpForm.controls.providerId.setValue("<nil>")
    // this.getSeekerHelpForm.controls.userId.setValue(this.userId)
    // this.getSeekerHelpForm.controls.location.setValue(this.latitude+"|"+this.longitude)
    this.service.sendAssistRequest(this.getSeekerHelpForm.value)
      .then(response => { this.successMessage = response,this.showFullForm = false,this.showLoading=true,console.clear(),this.toastMessage = "REQUEST GENERATED. ID : ' " + this.successMessage + " '", this.launch_toast(),this.fetchSeeker(response) })
      .catch(error => this.errorMessage = error.message)
  }

  //IF Request is Approved
  fetchSeeker(requestId)
  {
    // console.log(typeof(requestId)
    if(this.token=true && this.counter<this.limit)
    {
    setTimeout(() => {
      this.service.getApprovedService(requestId)
      .then(response=>{this.checkStatus(response)})
      .catch(error =>{this.counter+=1,this.fetchSeeker(requestId)})
    }, 3000);
    }
    else
    {
      this.timeOut=true;
    }
  }
  checkStatus(request)
  {
    if(request.status=="inProgress")
    {
      this.token=false;
      this.counter=60;
      this.showLoading=false
      // console.log(request)
      this.service.getServiceProvider(request.providerId)
      .then(response=>{sessionStorage.setItem("seekerRequest",JSON.stringify(request));
                       sessionStorage.setItem("requestId",JSON.stringify(request.requestId));
                       sessionStorage.setItem("providerDetails",JSON.stringify(response)),
                       this.router.navigate(["seekerServicing"])})
      .catch(error =>{this.counter++})
      
    }
    else
    {
      this.counter++;
    }
  }

  retryCheck()
  {
    this.counter=0
    this.showLoading=true;
    this.timeOut=false;
    console.clear();
    this.fetchSeeker(this.successMessage);
  }

  launch_toast() {
    var x = document.getElementById("toast")
    x.className = "show";
    setTimeout(function () { x.className = x.className.replace("show", ""); }, 5000);
  }
  ngOnInit() {
    this.timeOut=false;
    this.counter=0
    this.showFullForm = true
    this.showLoading=false
    this.launch_toast()
    this.getSeekerHelpForm = this.fb.group({
      vtype: ['', [Validators.required]],
      vmanuf: ['', [Validators.required]],
      vmodel: ['', [Validators.required]],
      vehnum: ['', [Validators.pattern("[A-Z]{2}-[0-9]{2}-[A-Z]{2,3}-[0-9]{4}"), Validators.required]],
      vproblem: ['', [Validators.required]],
      probdescr: ['', [Validators.required]],
      seekerId: [''],
      location: [''],
      estimatedCost: [''],
      status:[''],
      providerId:['']
    })
    this.errorMessage = null
    this.successMessage = null
    this.estimate = null
    this.manuf_data = null
    this.model_data = null
    if (sessionStorage.getItem("userId") && sessionStorage.getItem("location")) {
      this.userId = sessionStorage.getItem("userId")
      this.location = sessionStorage.getItem("location")
      this.latitude = sessionStorage.getItem("latitude")
      this.longitude = sessionStorage.getItem("longitude")
      //console.log(this.userId)
    }
    else {
      alert("Sorry. We are facing some issue.Try Logging in again")
      localStorage.clear()
      localStorage.setItem("userType", "seeker")
      sessionStorage.clear()
      this.router.navigate(["helpSeeker"])
    }
  }

  ngOnDestroy(){
this.token=false
  }
}
