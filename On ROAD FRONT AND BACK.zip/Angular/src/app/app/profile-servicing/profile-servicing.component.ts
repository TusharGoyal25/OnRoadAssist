import { Component, OnInit } from '@angular/core';
import { ProviderServicingService } from './provider-servicing.service';
import { Router } from '@angular/router';
declare let Swal: any;

@Component({
  selector: 'app-profile-servicing',
  templateUrl: './profile-servicing.component.html',
  styleUrls: ['./profile-servicing.component.css']
})
export class ProfileServicingComponent implements OnInit {
  seeker
  error
  seekerRequest
  address
  distanceToTravel
  travelCharge
  totalAmount
  successMessage

  constructor(public service:ProviderServicingService,public routes:Router) { }


  showDirections() {
    window.open(localStorage.getItem("directions"), "_blank")
  }
  closeService()
  {
   let data={
     "status":"closed",
     "requestId":this.seekerRequest.requestId
               }
    Swal.fire({
      title: 'Sure to Close?',
      text: "Are you sure you want to Close this Request",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Service Completed'
    }).then((result) => {
      if (result.value) {
        this.service.closeServiceStatus(data)
        .then(response=>{
          Swal.fire(
            'Please Collect ₹ '+(''+this.totalAmount).substring(0,7),
            'Service Closed SuccessFully',
            'success');
          window.history.back()
          })
      }
    })
  }

  ngOnInit() {
    if (JSON.parse(localStorage.getItem("address")) != null && JSON.parse(localStorage.getItem("request")) != null && JSON.parse(localStorage.getItem("seeker")) != null) {
      this.address = JSON.parse(localStorage.getItem("address"))
      this.seekerRequest = JSON.parse(localStorage.getItem("request"))
      this.seeker = JSON.parse(localStorage.getItem("seeker"))
      this.distanceToTravel = this.distance(
        sessionStorage.getItem("orginLat"),
        sessionStorage.getItem("orginLon"),
        sessionStorage.getItem("desLat"),
        sessionStorage.getItem("desLon"))
        //console.log(this.distanceToTravel)
      if(this.distanceToTravel!=null)
      {
        this.travelCharge=3*this.distanceToTravel
        if(new Date().getHours()>=21 || new Date().getHours()<6)
        {
          this.travelCharge=5*this.distanceToTravel
        }
        if(this.travelCharge<30.0)
        {
          this.travelCharge=30.0
        }
        this.totalAmount=(+this.travelCharge)+(+this.seekerRequest.estimatedCost)
        this.distanceToTravel=this.distanceToTravel+'';
      
      }
      
    }
    else {
      console.log("Error Occured")
      window.history.back()
    }
  }
  distance(lat1, lon1, lat2, lon2, unit = "K") {
    if ((lat1 == lat2) && (lon1 == lon2)) {
      return null;
    }
    else {
      var radlat1 = Math.PI * lat1 / 180;
      var radlat2 = Math.PI * lat2 / 180;
      var theta = lon1 - lon2;
      var radtheta = Math.PI * theta / 180;
      var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
      if (dist > 1) {
        dist = 1;
      }
      dist = Math.acos(dist);
      dist = dist * 180 / Math.PI;
      dist = dist * 60 * 1.1515;
      if (unit == "K") { dist = dist * 1.609344 }
      if (unit == "N") { dist = dist * 0.8684 }
      return dist;
    }
  }
  redirectBack()
  {
    window.history.back()
  }
}
