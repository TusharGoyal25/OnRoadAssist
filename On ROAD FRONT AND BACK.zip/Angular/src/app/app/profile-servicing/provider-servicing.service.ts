import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class ProviderServicingService {

  constructor(public http:Http) { }


  closeServiceStatus(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/setServiceRequestStatus",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

 

  handleError(error){
    return Promise.reject(error.json());
  }
}
