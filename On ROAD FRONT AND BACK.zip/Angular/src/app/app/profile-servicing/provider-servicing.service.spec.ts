import { TestBed, inject } from '@angular/core/testing';

import { ProviderServicingService } from './provider-servicing.service';

describe('ProviderServicingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProviderServicingService]
    });
  });

  it('should be created', inject([ProviderServicingService], (service: ProviderServicingService) => {
    expect(service).toBeTruthy();
  }));
});
