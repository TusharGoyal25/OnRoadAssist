import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileServicingComponent } from './profile-servicing.component';

describe('ProfileServicingComponent', () => {
  let component: ProfileServicingComponent;
  let fixture: ComponentFixture<ProfileServicingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileServicingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileServicingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
