import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class PreviousAvailedService {

  constructor(public http:Http) { }

  getPreAvailed_Seeker(seekedId):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/getPreAvailed_Seeker",seekedId)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  saveUsersRating(ratingData):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/saveUsersRating",ratingData)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }


  getPreAvailed_Provider(providerId):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/getPreAvailed_Provider",providerId)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  closeServiceStatus(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/setServiceRequestStatus",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
  }

  handleError(error){
    return Promise.reject(error.json());
  }

}
