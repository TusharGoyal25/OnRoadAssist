import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviousAvailedComponent } from './previous-availed.component';

describe('PreviousAvailedComponent', () => {
  let component: PreviousAvailedComponent;
  let fixture: ComponentFixture<PreviousAvailedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviousAvailedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviousAvailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
