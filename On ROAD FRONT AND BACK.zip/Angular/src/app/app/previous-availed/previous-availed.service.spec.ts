import { TestBed, inject } from '@angular/core/testing';

import { PreviousAvailedService } from './previous-availed.service';

describe('PreviousAvailedService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PreviousAvailedService]
    });
  });

  it('should be created', inject([PreviousAvailedService], (service: PreviousAvailedService) => {
    expect(service).toBeTruthy();
  }));
});
