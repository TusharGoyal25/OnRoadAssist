import { Component, OnInit } from '@angular/core';
import { PreviousAvailedService } from './previous-availed.service';
import { FormBuilder } from '@angular/forms';
declare let Swal: any;


@Component({
  selector: 'app-previous-availed',
  templateUrl: './previous-availed.component.html',
  styleUrls: ['./previous-availed.component.css']
})
export class PreviousAvailedComponent implements OnInit {
  loadShow
  seekerLoad
  providerLoad
  availedServiceList
  ratingChartForm
  feedRequest
  showRatingForm
  constructor(public service:PreviousAvailedService,public fb:FormBuilder) { }


  skipFeedback()
  {
    this.showRatingForm=false;
  }

  showFeedback(request)
  {
    this.showRatingForm=true;
    this.ratingChartForm.controls.rate1.setValue('1');
    this.ratingChartForm.controls.rate2.setValue('1');
    this.ratingChartForm.controls.rate3.setValue('1');
    this.feedRequest=request;
    console.log(request.rating)
  }
  submitFeedback()
  {
    
    this.ratingChartForm.controls.seekerId.setValue(sessionStorage.getItem("userId"));
    this.ratingChartForm.controls.providerId.setValue(this.feedRequest.providerId);
    this.ratingChartForm.controls.requestId.setValue(this.feedRequest.requestId);
    console.log(this.ratingChartForm.value);
    this.service.saveUsersRating(this.ratingChartForm.value)
    .then(response=>{this.showRatingForm=false,this.loadData()})
    .catch(error=>{console.log("Error Occured, Data Invalid")})
   
  }
  
  ngOnInit() {
    this.loadShow=true;
    this.showRatingForm=false
    this.ratingChartForm=this.fb.group({
      rate1:['1'],
      rate2:['1'],
      rate3:['1'],
      seekerId:[''],
      providerId:[''],
      requestId:['']
  })

    this.availedServiceList=null
    this.seekerLoad=false
    this.providerLoad=false
    if(sessionStorage.getItem("userType")=="seeker")
    {
      this.seekerLoad=true
      this.providerLoad=false
      this.loadSeekerData()
    }
    else if(sessionStorage.getItem("userType")=="provider")
    {
      this.seekerLoad=false
      this.providerLoad=true
      this.loadProviderData()
    }
    else
    {
      alert("Some error occured. Please try again")
      window.history.back()
    }
  }

  loadProviderData()
  {
    this.service.getPreAvailed_Provider(sessionStorage.getItem("userId"))
    .then(response=>{this.availedServiceList=response,this.loadShow=false})
    .catch(error=>{console.log("Error Occured, Data Invalid"),this.loadShow=false})
  }

  loadSeekerData()
  {
    this.service.getPreAvailed_Seeker(sessionStorage.getItem("userId"))
    .then(response=>{this.availedServiceList=response,this.loadShow=false})
    .catch(error=>{console.log("Error Occured, Data Invalid"),this.loadShow=false})
  }

  openDirections(request)
  {
      let desLat=request.location.split("|")[0]
      let desLon=request.location.split("|")[1]
      let orginLat=sessionStorage.getItem("latitude")
      let orginLon=sessionStorage.getItem("longitude")
      window.open("https://www.google.com/maps/dir/?api=1&origin="+orginLat+","+orginLon+"&destination="+desLat+","+desLon+"&travelmode=driving","_blank")
  }

  closeService(request)
  {

  console.log(request.requestId)
   let data={
     "status":"closed",
     "requestId":request.requestId
               }
    Swal.fire({
      title: 'Sure to Close?',
      text: "Are you sure you want to Close this Request",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Close Service'
    }).then((result) => {
      if (result.value) {
        this.service.closeServiceStatus(data)
        .then(response=>{
          Swal.fire(
            'Service Closed SuccessFully',
            'Happy to Help :)',
            'success'),
            this.loadData()
          })
      }
    })
  }
  loadData()
  {
    if(sessionStorage.getItem("userType")=="seeker")
            {
              this.loadSeekerData()
            }
    else
    {
      this.loadProviderData()
    }
  }

}
