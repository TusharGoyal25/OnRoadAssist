import { Component, OnInit } from '@angular/core';
import { PasswordResetService } from './password-reset.service';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import {Location} from '@angular/common';
import { Validators } from '@angular/forms';
import { PasswordValidator } from './password.validator';

@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html',
  styleUrls: ['./password-reset.component.css']
})
export class PasswordResetComponent implements OnInit {
  showFormFlag1
  showFormFlag2

  errorMessage1
  errorMessage2
  successMessage
  userIdForm
  userType
  isPass
  showPass()
  {
   
    var pass=document.getElementById("passField")
    if(pass.getAttribute("type")=="password")
    {
      this.isPass=false;
      pass.setAttribute("type","text")
    }
    else if(pass.getAttribute("type")=="text")
    {
      this.isPass=true;
      pass.setAttribute("type","password")
    }
  }
  constructor(public service: PasswordResetService, public fb1:FormBuilder,public fb2:FormBuilder,public location:Location,public router:Router) { 
    
  }

  checkDatabaseForm=this.fb1.group({
    userId:['',[Validators.required,Validators.email]],
    answer:['',[Validators.required]],
    question:['',[Validators.required]]
  })

  updatePasswordForm=this.fb2.group({
    userId:[''],
    password:['',[Validators.required,Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(.{8,32}$)")]],
    confPassword:['',[Validators.required]]}
  ,{validator:PasswordValidator.checkPass})


  checkDatabase()
  {
    this.showFormFlag2=false;
    this.errorMessage2=null;
    this.errorMessage1=null;
    this.userIdForm=this.checkDatabaseForm.controls.userId.value
    this.service.databaseCheckPost(this.checkDatabaseForm.value)
    .then(response=>{this.showFormFlag2=response,this.showFormFlag1=false})
    .catch(error=>this.errorMessage1=error.message)
  }

  updatePassword()
  {
    this.updatePasswordForm.controls.userId.setValue(this.userIdForm)
    this.errorMessage1=null
    this.errorMessage2=null
    this.service.changePasswordPost(this.updatePasswordForm.value)
    .then(response=>{this.successMessage=response.password,this.showFormFlag2=false})
    .catch(error=>this.errorMessage2=error.message)
  }
  loginSeekerRedirect()
  {
    if(sessionStorage.getItem("userType")=="seeker")
      {this.router.navigate(['helpSeeker']);}
    else if(sessionStorage.getItem("userType")=="provider")
    {this.router.navigate(['helpProvider']);}
  }
  ngOnInit() {      
    this.isPass=true;
    this.showFormFlag1=true;
    this.showFormFlag2=false;
    if(sessionStorage.getItem("userType")==null)
    {
        alert("Some Error Happend. Can't Redirect right now.");
        this.location.back();
    }
    else
    {
        this.userType=sessionStorage.getItem("userType");
    }
  
  }
}
