import { AbstractControl } from "@angular/forms";


export class PasswordValidator {
    static checkPass(AC: AbstractControl) {
        let password = AC.get('password').value; // to get value in input tag
        let confirmPassword = AC.get('confPassword').value; // to get value in input tag
         if(password != confirmPassword) {
             AC.get('confPassword').setErrors( {checkPass: true} )
         } else {
             return null
         }
    }

}