import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class PasswordResetService {

  constructor(public http:Http) { }

  databaseCheckPost(data):Promise<any>
  {
    if(sessionStorage.getItem("userType")=="seeker")
    {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/seeker_forget_password",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
    }

   if(sessionStorage.getItem("userType")=="provider")
   {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/provider_forget_password",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
    }

  }
  changePasswordPost(data):Promise<any>
  {
    if(sessionStorage.getItem("userType")=="seeker")
    {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/seeker_update_password",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
    }
    if(sessionStorage.getItem("userType")=="provider")
    {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/provider_update_password",data)
    .toPromise()
    .then(response=>response.json())
    .catch(this.handleError)
    }
    
  }

  handleError(error){
    return Promise.reject(error.json());
  }
}
