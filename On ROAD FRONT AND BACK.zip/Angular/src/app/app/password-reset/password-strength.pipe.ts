import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'passwordStrength'
})
export class PasswordStrengthPipe implements PipeTransform {

  transform(value: any): any {
   let passwordstr:string;
   let len;
   len=value.length;+1;
   if(len<=6)
   {
    passwordstr="Weak"
   }
   else if(len>6 && len<=8)
   {
     passwordstr="Moderate"
  }
  else if(len>8)
  {
    passwordstr="Strong"
  }
  return passwordstr

  }


}
