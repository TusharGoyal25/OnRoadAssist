import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatephnoComponent } from './updatephno.component';

describe('UpdatephnoComponent', () => {
  let component: UpdatephnoComponent;
  let fixture: ComponentFixture<UpdatephnoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatephnoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatephnoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
