import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { FormBuilder } from '@angular/forms';
import { UpdatePhoneService } from './update-phone.service';
import { Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PhoneNumberValidator } from './phonenumber.validator';

@Component({
  selector: 'app-updatephno',
  templateUrl: './updatephno.component.html',
  styleUrls: ['./updatephno.component.css']
})
export class UpdatephnoComponent implements OnInit {

  constructor(public http:Http,public fb:FormBuilder,public service:UpdatePhoneService,public router:Router ) { }
  errorMessage
  userIdForm
  showForm=true
  successMessage
  userSessionId
  updatePhoneForm=this.fb.group({
    userId:[''],
    phoneNumber :['',[Validators.required,Validators.pattern("[5-9][0-9]{9}"),PhoneNumberValidator.noRepeat]]
    
    
  })
  ngOnInit() {
    this.userIdForm=this.updatePhoneForm.controls.userId.value;
    this.userSessionId=sessionStorage.getItem("userId");
  }  
  updatePhone()
  { 
    this.errorMessage=null
    this.updatePhoneForm.controls.userId.setValue(this.userSessionId)
    //console.log(this.updatePhoneForm.value)
    this.service.updatePhone(this.updatePhoneForm.value)
    .then(response=>{this.successMessage=response.message,this.showForm=false})
    .catch(error=>this.errorMessage=error.message)
   
  
  }

}