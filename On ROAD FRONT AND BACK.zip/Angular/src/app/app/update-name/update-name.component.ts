import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { UpdateNameService } from './update-name.service';

@Component({
  selector: 'app-update-name',
  templateUrl: './update-name.component.html',
  styleUrls: ['./update-name.component.css']
})
export class UpdateNameComponent implements OnInit {
  successMessage
  constructor(public http:Http,public fb:FormBuilder,public ns:UpdateNameService) { }
  updateNameForm:FormGroup
  errorMessage 
  userSessionId
  showForm=true
  ngOnInit() {
    this.userSessionId=sessionStorage.getItem("userId");
    this.updateNameForm=this.fb.group({
      userId:[''],
      name:['',[Validators.required,Validators.pattern("[A-Z][a-zA-Z][^0-9#&<>\"~;$^%{}?]{1,50}[^ ]")]]
    })
  }
updateName()
{ this.successMessage=null
  this.errorMessage=null
  this.updateNameForm.controls.userId.setValue(this.userSessionId)
    this.ns.updateName(this.updateNameForm.value)
    .then(response=>{this.successMessage=response.message,this.showForm=false})
    .catch(error=>this.errorMessage=error.message)
}
}
