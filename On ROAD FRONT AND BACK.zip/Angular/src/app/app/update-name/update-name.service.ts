import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class UpdateNameService {

  constructor(public http:Http) { }
updateName(data):Promise<any>
{
  if(localStorage.getItem("userType")=="seeker")
  {
  return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/seekerupdatename",data)
  .toPromise()
  .then(response=>response.json() as any)
  .catch(this.handleError)
  }
  if(localStorage.getItem("userType")=="provider")
  {
  return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/providerupdatename",data)
  .toPromise()
  .then(response=>response.json() as any)
  .catch(this.handleError)
  }
}

handleError(error){
  return Promise.reject(error.json());
}
}
