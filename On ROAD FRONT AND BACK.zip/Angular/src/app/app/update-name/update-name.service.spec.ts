import { TestBed, inject } from '@angular/core/testing';

import { UpdateNameService } from './update-name.service';

describe('UpdateNameService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UpdateNameService]
    });
  });

  it('should be created', inject([UpdateNameService], (service: UpdateNameService) => {
    expect(service).toBeTruthy();
  }));
});
