import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { HelpSeekerLoginService } from '../help-seeker/help-seeker-login.service';
import { Router } from '@angular/router';
import { HelpProviderLoginService } from './help-provider-login.service';

@Component({
  selector: 'app-help-provider',
  templateUrl: './help-provider.component.html',
  styleUrls: ['./help-provider.component.css']
})
export class HelpProviderComponent implements OnInit {


  isPass
  showPass()
  {
   
    var pass=document.getElementById("passField")
    if(pass.getAttribute("type")=="password")
    {
      this.isPass=false;
      pass.setAttribute("type","text")
    }
    else if(pass.getAttribute("type")=="text")
    {
      this.isPass=true;
      pass.setAttribute("type","password")
    }
  }
  constructor(public fb:FormBuilder,public service:HelpProviderLoginService,public router: Router) { }
  errorMessage:string
  providerLogin=this.fb.group({
    userId:['',[Validators.required,Validators.minLength(10),Validators.email]],
    password:['',[Validators.required,Validators.minLength(8)]]
    
  })
  loginProvider()
  {
    this.errorMessage=null
    this.service.loginPost(this.providerLogin.value)
    .then(response=>{sessionStorage.setItem("userId",response.userId),localStorage.setItem("active","true");sessionStorage.setItem("userName",response.name), this.router.navigate(['/profileProvider']);})
    .catch(error=>this.errorMessage=error.message)
  }
  providerRegRedirect()
  {
    this.router.navigate(['/registerProvider']);
    // this.router.navigate(['/seekerServicing']);
  }
  resetPassword()
  {
    sessionStorage.setItem("userType","provider");
    this.router.navigate(['passwordReset']);
  }
  ngOnInit() {
    this.isPass=true;
    if (sessionStorage.length > 0) {
      sessionStorage.clear();
    }
  }

}