import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpProviderComponent } from './help-provider.component';

describe('HelpProviderComponent', () => {
  let component: HelpProviderComponent;
  let fixture: ComponentFixture<HelpProviderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HelpProviderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpProviderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
