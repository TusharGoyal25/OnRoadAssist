import { TestBed, inject } from '@angular/core/testing';

import { HelpProviderLoginService } from './help-provider-login.service';

describe('HelpProviderLoginService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HelpProviderLoginService]
    });
  });

  it('should be created', inject([HelpProviderLoginService], (service: HelpProviderLoginService) => {
    expect(service).toBeTruthy();
  }));
});
