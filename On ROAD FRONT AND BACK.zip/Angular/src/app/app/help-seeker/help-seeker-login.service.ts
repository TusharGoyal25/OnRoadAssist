import { Injectable } from '@angular/core';
import { Http } from '@angular/http';


@Injectable()
export class HelpSeekerLoginService {
  constructor(public http:Http) { }

  loginPost(data:Promise<any>)
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/seeker_login",data)
    .toPromise()
    // .then(response=>response.text())
    .then(response=>response.json())
    .catch(this.handleError)
  }
  handleError(error)
  {
    // return Promise.reject(error.text());
    return Promise.reject(error.json());
  }
}
