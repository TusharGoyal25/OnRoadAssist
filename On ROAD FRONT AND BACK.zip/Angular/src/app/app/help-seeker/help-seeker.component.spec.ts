import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpSeekerComponent } from './help-seeker.component';

describe('HelpSeekerComponent', () => {
  let component: HelpSeekerComponent;
  let fixture: ComponentFixture<HelpSeekerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HelpSeekerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpSeekerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
