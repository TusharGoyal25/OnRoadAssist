import { TestBed, inject } from '@angular/core/testing';

import { HelpSeekerLoginService } from './help-seeker-login.service';

describe('HelpSeekerLoginService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HelpSeekerLoginService]
    });
  });

  it('should be created', inject([HelpSeekerLoginService], (service: HelpSeekerLoginService) => {
    expect(service).toBeTruthy();
  }));
});
