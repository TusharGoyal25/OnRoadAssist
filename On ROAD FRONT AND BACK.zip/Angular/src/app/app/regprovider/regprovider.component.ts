import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PasswordValidator } from '../regseeker/password.validator';
import { RegisterProviderService } from './register-provider.service';
import { PhoneNumberValidator } from './phonenumber.validator';

@Component({
  selector: 'app-regprovider',
  templateUrl: './regprovider.component.html',
  styleUrls: ['./regprovider.component.css']
})
export class RegproviderComponent implements OnInit {

  constructor(public service:RegisterProviderService,public fb:FormBuilder,public router:Router) { }
  successId:string
  emailId
  showForm
  userName
  mobile
  pass
  answer
  flag
  errorMessage:string
  data
  registrationProviderForm:FormGroup
  isPass
  showPass()
  {
   
    var pass=document.getElementById("passField")
    if(pass.getAttribute("type")=="password")
    {
      this.isPass=false;
      pass.setAttribute("type","text")
    }
    else if(pass.getAttribute("type")=="text")
    {
      this.isPass=true;
      pass.setAttribute("type","password")
    }
  }
  registerProvider()
  {
    this.successId=null;
    this.errorMessage=null;
    this.service.registerPost(this.registrationProviderForm.value)
    .then(response=>{this.successId=response,this.showForm=false,this.flag=1})
    .catch(error=>this.errorMessage=error)
    if(this.flag==1)
    {
      this.router.navigate(["helpProvider"]);
    }
   
  }
  loginSeekerRedirect()
  {
    this.router.navigate(["helpProvider"]);
  }

 
  ngOnInit() {
    this.showForm=true
    this.isPass=true;
    this.registrationProviderForm=this.fb.group({
      name:['',[Validators.required,Validators.pattern("[A-Z][a-zA-Z][^0-9#&<>\"~;$^%{}?]{1,50}[^ ]")]],
      password:['',[Validators.required,Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(.{8,32}$)")]],
      confPassword:['',[Validators.required]],
      userId:['',[Validators.required,Validators.email]],
      phoneNumber:['',[Validators.required,Validators.pattern("[5-9][0-9]{9}"),PhoneNumberValidator.noRepeat]],
      question:['',[Validators.required]],
      answer:['',[Validators.required]],
    },{validator:PasswordValidator.checkPass})
  }
  }