import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegproviderComponent } from './regprovider.component';

describe('RegproviderComponent', () => {
  let component: RegproviderComponent;
  let fixture: ComponentFixture<RegproviderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegproviderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegproviderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
