import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class RegisterProviderService {

  constructor(private http:Http) { }
  registerPost(data):Promise<any>
  {
    return this.http.post("http://localhost:3333/UDAI_BackEnd/ProjectAPI/addProvider",data)
    .toPromise()
    .then(response=>response.text())
    .catch(this.handleError)
  }

  handleError(error){
    return Promise.reject(error.text());
  }

}
