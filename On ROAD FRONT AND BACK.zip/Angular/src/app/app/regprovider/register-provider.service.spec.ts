import { TestBed, inject } from '@angular/core/testing';

import { RegisterProviderService } from './register-provider.service';

describe('RegisterProviderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RegisterProviderService]
    });
  });

  it('should be created', inject([RegisterProviderService], (service: RegisterProviderService) => {
    expect(service).toBeTruthy();
  }));
});
