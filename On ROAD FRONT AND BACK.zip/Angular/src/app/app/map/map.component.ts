import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {
  locForm:FormGroup
  src="https://maps.google.com/maps?q=india&t=&z=13&ie=UTF8&iwloc=&output=embed"
 
  constructor(private fb:FormBuilder) { }

  ngOnInit() {
    this.locForm=this.fb.group(
      {
        location:['India',]
      }
    )
  }
  search()
  {
    this.src=this.locForm.get('location').value
  }

}
