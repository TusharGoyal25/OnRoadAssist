package com.infy.dao;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.ProblemCostEntity;
import com.infy.entity.ProblemTableEntity;
import com.infy.entity.ProviderLocationEntity;
import com.infy.entity.ProviderStatusEntity;
import com.infy.entity.ServiceCostEntity;
import com.infy.entity.ServiceProviderEntity;
import com.infy.entity.ServiceSeekerEntity;
import com.infy.entity.SiteFeedBackEntity;
import com.infy.entity.VehicleDataEntity;
import com.infy.model.AvailedServices;
import com.infy.model.ProblemTable;
import com.infy.model.ProviderLocation;
import com.infy.model.ProviderStatus;
import com.infy.model.ServiceCost;
import com.infy.model.ServiceProvider;
import com.infy.model.ServiceSeeker;
import com.infy.model.SiteFeedBack;
import com.infy.model.UserRating;

@Repository(value="Projectdao")
public class ProjectDAOImpl implements ProjectDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	
		
		public String addSeeker(ServiceSeeker seeker) {
			Session session = sessionFactory.getCurrentSession();
			ServiceSeekerEntity ce = new ServiceSeekerEntity();
	        ce.setUserId(seeker.getUserId());
	        ce.setPhoneNumber(seeker.getPhoneNumber());
	        ce.setPassword(seeker.getPassword());
	        ce.setName(seeker.getName());
	        ce.setQuestion(seeker.getQuestion());
	        ce.setAnswer(seeker.getAnswer());
	       
	        
	        session.persist(ce);
	        return seeker.getUserId();
		
	}
		
	@Override
	public ServiceSeeker seeker_login(ServiceSeeker seeker)
	{
		ServiceSeeker s=new ServiceSeeker();
		
		Session session = sessionFactory.getCurrentSession();
		ServiceSeekerEntity se = (ServiceSeekerEntity) session.get(ServiceSeekerEntity.class,seeker.getUserId());
        
		//System.out.println(se.getUserId());
		if(se!=null)
        {
        	
        
		s.setPassword(se.getPassword());
         s.setUserId(se.getUserId());
         s.setAnswer(se.getAnswer());
         s.setName(se.getName());
         s.setPhoneNumber(se.getPhoneNumber());
         s.setQuestion(se.getQuestion());
         if(s.getUserId().equals(seeker.getUserId()) && s.getPassword().equals(seeker.getPassword()))
         {
         	return s;
         }
        }
		
        
        
        	return null;
        
        
        
        
		
	}
	
	
	
	
	
	
	
	
	@Override
	
	
	public String addProvider(ServiceProvider provider) {
		Session session = sessionFactory.getCurrentSession();
		ServiceProviderEntity ce = new ServiceProviderEntity();
        ce.setUserId(provider.getUserId());
        ce.setPhoneNumber(provider.getPhoneNumber());
        ce.setPassword(provider.getPassword());
        ce.setName(provider.getName());
        ce.setQuestion(provider.getQuestion());
        ce.setAnswer(provider.getAnswer());
        ce.setRating("0");
        
        session.persist(ce);
        return provider.getUserId();
	
}
	
@Override
public ServiceProvider provider_login(ServiceProvider provider)
{
	ServiceProvider s=new ServiceProvider();
	
	Session session = sessionFactory.getCurrentSession();
	ServiceProviderEntity se = (ServiceProviderEntity) session.get(ServiceProviderEntity.class,provider.getUserId());
    
	//System.out.println(se.getUserId());
	if(se!=null)
    {
    	
    
	s.setPassword(se.getPassword());
     s.setUserId(se.getUserId());
     s.setAnswer(se.getAnswer());
     s.setName(se.getName());
     s.setPhoneNumber(se.getPhoneNumber());
     s.setQuestion(se.getQuestion());
     if(s.getUserId().equals(provider.getUserId()) && s.getPassword().equals(provider.getPassword()))
     {
     	return s;
     }
    }
	
    
    
    	return null;
    
    
    
    
	
}

@Override
public ServiceSeeker seeker_forget_password(ServiceSeeker seeker)
{
	ServiceSeeker s=new ServiceSeeker();
	
	Session session = sessionFactory.getCurrentSession();
	ServiceSeekerEntity se = (ServiceSeekerEntity) session.get(ServiceSeekerEntity.class,seeker.getUserId());
    
	//System.out.println(se.getUserId());
	if(se!=null)
    {
    	
    
	s.setPassword(se.getPassword());
     s.setUserId(se.getUserId());
     s.setAnswer(se.getAnswer());
     s.setName(se.getName());
     s.setPhoneNumber(se.getPhoneNumber());
     s.setQuestion(se.getQuestion());
     if(s.getUserId().equals(seeker.getUserId()) && s.getQuestion().equals(seeker.getQuestion())&& s.getAnswer().equals(seeker.getAnswer()))
     {
     	return s;
     }
    }
	
    
    
    	return null;
   }	
	
@Override
public ServiceSeeker seeker_update_password(ServiceSeeker seeker){
	Session session = sessionFactory.getCurrentSession();
	ServiceSeekerEntity se= session.get(ServiceSeekerEntity.class, seeker.getUserId());
	ServiceSeeker s=new ServiceSeeker();
	
	if(	se !=null) {
		se.setPassword(seeker.getPassword());
		s.setPassword(se.getPassword());
         s.setUserId(se.getUserId());
         s.setAnswer(se.getAnswer());
         s.setName(se.getName());
         s.setPhoneNumber(se.getPhoneNumber());
         s.setQuestion(se.getQuestion());
		return seeker;
	}
	return null;
}	


@Override
public ServiceProvider provider_forget_password(ServiceProvider provider)
{
	ServiceProvider s=new ServiceProvider();
	
	Session session = sessionFactory.getCurrentSession();
	ServiceProviderEntity se = (ServiceProviderEntity) session.get(ServiceProviderEntity.class,provider.getUserId());
    
	//System.out.println(se.getUserId());
	if(se!=null)
    {
    	
    
	s.setPassword(se.getPassword());
     s.setUserId(se.getUserId());
     s.setAnswer(se.getAnswer());
     s.setName(se.getName());
     s.setPhoneNumber(se.getPhoneNumber());
     s.setQuestion(se.getQuestion());
     if(s.getUserId().equals(provider.getUserId()) && s.getQuestion().equals(provider.getQuestion())&& s.getAnswer().equals(provider.getAnswer()))
     {
     	return s;
     }
    }
	
    
    
    	return null;
   }	
	
@Override
public ServiceProvider provider_update_password(ServiceProvider provider){
	Session session = sessionFactory.getCurrentSession();
	ServiceProviderEntity se= session.get(ServiceProviderEntity.class, provider.getUserId());
	ServiceProvider s=new ServiceProvider();
	
	if(	se !=null) {
		se.setPassword(provider.getPassword());
		s.setPassword(se.getPassword());
         s.setUserId(se.getUserId());
         s.setAnswer(se.getAnswer());
         s.setName(se.getName());
         s.setPhoneNumber(se.getPhoneNumber());
         s.setQuestion(se.getQuestion());
		return provider;
	}
	return null;
}


@Override
public ServiceSeeker seeker_update_phoneno(ServiceSeeker seeker) {
	Session session = sessionFactory.getCurrentSession();
	ServiceSeekerEntity seekerEntity = session.get(ServiceSeekerEntity.class, seeker.getUserId());
	if(	seekerEntity !=null) {
		seekerEntity.setPhoneNumber(seeker.getPhoneNumber());
		return seeker;
	}
	return null;
}
		
@Override
    public List<String> getCompanyName(String vehicleType) throws Exception {
 
        
        
        Session session = null;
        
       
        session = sessionFactory.getCurrentSession();

        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);

        Root<VehicleDataEntity> root = criteriaQuery.from(VehicleDataEntity.class);
        criteriaQuery.select(root.get("companyName")).distinct(true);
        criteriaQuery.where(builder.equal(root.get("vehicleType"), vehicleType));

        List<String> nameList = session.createQuery(criteriaQuery).list();
        return nameList;
          
    }		


@Override
public List<String> getModelName(String companyName) throws Exception {

    
    
    Session session = null;
    
   
    session = sessionFactory.getCurrentSession();

    CriteriaBuilder builder = session.getCriteriaBuilder();
    CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);

    Root<VehicleDataEntity> root = criteriaQuery.from(VehicleDataEntity.class);
    criteriaQuery.select(root.get("modelName"));
    criteriaQuery.where(builder.equal(root.get("companyName"), companyName));

    List<String> nameList = session.createQuery(criteriaQuery).list();
    return nameList;
      
}	
		
	

@Override
public  String getEstimatedCost(String vehicleType,String probType){

    
    
    Session session = null;
    
   
    session = sessionFactory.getCurrentSession();

    CriteriaBuilder builder = session.getCriteriaBuilder();
    CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);

    Root<ProblemCostEntity> root = criteriaQuery.from(ProblemCostEntity.class);
    criteriaQuery.select(root.get("estimatedCost"));
    criteriaQuery.where(builder.and(builder.equal(root.get("probType"), probType),builder.equal(root.get("vehicleType"), vehicleType)));

    String cost = session.createQuery(criteriaQuery).getSingleResult();
    return cost;
      
}		


		
		
@Override


public Integer savesAssistRequest(ProblemTable table) {
	Session session = sessionFactory.getCurrentSession();
	ProblemTableEntity ce = new ProblemTableEntity();
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MMM/yyyy HH:mm a");
	LocalDateTime now = LocalDateTime.now();
//	System.out.println(dtf.format(now).toString());
    ce.setRequestId(table.getRequestId());
    ce.setEstimatedCost(table.getEstimatedCost());
    ce.setLocation(table.getLocation());
    ce.setProbdescr(table.getProbdescr());
    ce.setSeekerId(table.getSeekerId());
    ce.setVproblem(table.getVproblem());
    ce.setVmanuf(table.getVmanuf());
    ce.setVtype(table.getVtype()); 
    ce.setVehnum(table.getVehnum());
    ce.setVmodel(table.getVmodel());
    ce.setStatus(table.getStatus());
    ce.setProviderId(table.getProviderId());
    ce.setReqDateTime(dtf.format(now).toString());
    ce.setRating("Not Rated");
    
    Integer requestid=(Integer)session.save(ce);
    return requestid;

}




@Override
public ProblemTable set_request_status(ProblemTable problems) {
	// TODO Auto-generated method stub
	Session session = sessionFactory.getCurrentSession();
	ProblemTableEntity problemTableEntity = session.get(ProblemTableEntity.class, problems.getRequestId());
	if(	problemTableEntity !=null) {
		System.out.println(problems.getStatus());
		problemTableEntity.setStatus(problems.getStatus());
		
		return problems;
	}
	return null;
}

@Override
public ProblemTable set_request_providerServiced(ProblemTable problems) {
	// TODO Auto-generated method stub
	Session session = sessionFactory.getCurrentSession();
	ProblemTableEntity problemTableEntity = session.get(ProblemTableEntity.class, problems.getRequestId());
	if(	problemTableEntity !=null) {
		problemTableEntity.setProviderId(problems.getProviderId());
		return problems;
	}
	return null;
}




		
		
@Override
public ServiceSeeker seeker_update_name(ServiceSeeker seeker) {
	Session session = sessionFactory.getCurrentSession();
	ServiceSeekerEntity seekerEntity = session.get(ServiceSeekerEntity.class, seeker.getUserId());
	if(	seekerEntity !=null) {
		seekerEntity.setName(seeker.getName());
		return seeker;
	}
	return null;
}

@Override


public String setStatus(ProviderStatus ps) {
       Session session = sessionFactory.getCurrentSession();
       ProviderStatusEntity pse =session.get(ProviderStatusEntity.class, ps.getProviderId());
//     ps.setProviderId(pse.getProviderId());
//     ps.setStatus(pse.getStatus());
      if(pse==null){
    	  ProviderStatusEntity p= new ProviderStatusEntity();	  
   p.setProviderId(ps.getProviderId());
    p.setStatus(ps.getStatus());
    session.persist(p);
    return p.getStatus();}
      else{
    	  
    	  pse.setStatus(ps.getStatus());
    	 return pse.getStatus();
      }
    
    
       
       


}
@Override
public ProblemTable provider_modify_cost(ProblemTable req){
Session session = sessionFactory.getCurrentSession();
ProblemTableEntity se= session.get(ProblemTableEntity.class,req.getRequestId());
ProblemTable s=new ProblemTable();

if(	se !=null) {
	se.setEstimatedCost(req.getEstimatedCost());
	s.setEstimatedCost(se.getEstimatedCost());
     
	return s;
}
return null;
}	



@Override
public ServiceSeeker seeker_reset_password(ServiceSeeker seeker)
{
	ServiceSeeker s=new ServiceSeeker();
	
	Session session = sessionFactory.getCurrentSession();
	ServiceSeekerEntity se = (ServiceSeekerEntity) session.get(ServiceSeekerEntity.class,seeker.getUserId());
    String p[]=seeker.getPassword().split("-");
    String opass=p[0];
    String npass=p[1];
	//System.out.println(se.getUserId());
	if(se!=null)
    {
    	
    
		s.setPassword(se.getPassword());
     s.setUserId(se.getUserId());
     
     if(s.getUserId().equals(seeker.getUserId()) && s.getPassword().equals(opass))
     {
    	 s.setUserId(se.getUserId());
         s.setAnswer(se.getAnswer());
         s.setName(se.getName());
         s.setPhoneNumber(se.getPhoneNumber());
         s.setQuestion(se.getQuestion());
    	 se.setPassword(npass);
    	 s.setPassword(se.getPassword());
    	 return s;
     }
    
    }
	
    
    
    	return null;
   }	
	
@Override
public ServiceProvider provider_reset_password(ServiceProvider provider)
{
	ServiceProvider s=new ServiceProvider();
	
	Session session = sessionFactory.getCurrentSession();
	ServiceProviderEntity se = (ServiceProviderEntity) session.get(ServiceProviderEntity.class,provider.getUserId());
    String p[]=provider.getPassword().split("-");
    String opass=p[0];
    String npass=p[1];
	//System.out.println(se.getUserId());
	if(se!=null)
    {
    	
    
		s.setPassword(se.getPassword());
     s.setUserId(se.getUserId());
     
     if(s.getUserId().equals(provider.getUserId()) && s.getPassword().equals(opass))
     {
    	 s.setUserId(se.getUserId());
         s.setAnswer(se.getAnswer());
         s.setName(se.getName());
         s.setPhoneNumber(se.getPhoneNumber());
         s.setQuestion(se.getQuestion());
    	 se.setPassword(npass);
    	 s.setPassword(se.getPassword());
    	 return s;
     }
    
    }
	
    
    
    	return null;
   }	
		


@Override


public String setProviderLocation(ProviderLocation l) {
	 Session session = sessionFactory.getCurrentSession();
	 ProviderLocationEntity pse =session.get(ProviderLocationEntity.class, l.getProviderId());
//   ps.setProviderId(pse.getProviderId());
//   ps.setStatus(pse.getStatus());
    if(pse==null){
  	  ProviderLocationEntity p= new ProviderLocationEntity();	  
 p.setProviderId(l.getProviderId());
  p.setLocation(l.getLocation());
  session.persist(p);
  return p.getLocation();}
    else{
  	  
  	  pse.setLocation(l.getLocation());
  	 return pse.getLocation();
    }
  
       
       


}

@Override
public ServiceProvider provider_update_name(ServiceProvider provider) {
	Session session = sessionFactory.getCurrentSession();
	ServiceProviderEntity providerEntity = session.get(ServiceProviderEntity.class, provider.getUserId());
	if(	providerEntity !=null) {
		providerEntity.setName(provider.getName());
		return provider;
	}
	return null;
}


@Override
public ServiceProvider provider_update_phoneno(ServiceProvider provider) {
	Session session = sessionFactory.getCurrentSession();
	ServiceProviderEntity providerEntity = session.get(ServiceProviderEntity.class, provider.getUserId());
	if(	providerEntity !=null) {
		providerEntity.setPhoneNumber(provider.getPhoneNumber());
		return provider;
	}
	return null;
}

@Override

public List<String> getNearestProvider(ProblemTable table){ 
	  Session session = sessionFactory.getCurrentSession();
  
  List<ProviderLocationEntity> allproviders = null;
	CriteriaBuilder builder = session.getCriteriaBuilder();
  CriteriaQuery<ProviderLocationEntity> criteriaQuery= builder.createQuery(ProviderLocationEntity.class);
  Root<ProviderLocationEntity> root = criteriaQuery.from(ProviderLocationEntity.class);
  criteriaQuery.select(root);
  List<String> li=new LinkedList<String>();
  allproviders = session.createQuery(criteriaQuery).list();
 
  String l2= table.getLocation();
	String li2[]=l2.split("\\|");
	Double x2 =Double.parseDouble(li2[0]);
	Double y2=Double.parseDouble(li2[1]);
	Map< Double, String> itemMap = new TreeMap< Double, String>();
	if(!allproviders.isEmpty()){
	for(Object o :allproviders)
	{ProviderLocationEntity e = (ProviderLocationEntity)o;
		ProviderStatusEntity pse =session.get(ProviderStatusEntity.class, e.getProviderId());
		if(pse!=null){
		if(pse.getStatus().equals("active")){
			String l1= e.getLocation();
			String li1[]=l1.split("\\|");
			Double x1 =Double.parseDouble(li1[0]);
			Double y1=Double.parseDouble(li1[1]);
			Double distance =Math.sqrt(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1)));
			itemMap.put(distance, e.getProviderId());
			
		}}
		
		
	}
	
	Collection<String> values = itemMap.values();
	if(!values.isEmpty())
	 {for(String val : values){
		 
		 li.add(val);
	 }}}
		return li; 

}



Double distance(Double lat1,Double lon1,Double lat2,Double lon2) {
    char unit='K';
	if ((lat1 == lat2) && (lon1 == lon2)) {
      return null;
    }
    else {
      Double radlat1 = Math.PI * lat1 / 180;
      Double radlat2 = Math.PI * lat2 / 180;
      Double theta = lon1 - lon2;
      Double radtheta = Math.PI * theta / 180;
      Double dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
      if (dist > 1) {
        dist = 1.0;
      }
      dist = Math.acos(dist);
      dist = dist * 180 / Math.PI;
      dist = dist * 60 * 1.1515;
      if (unit == 'K') { dist = dist * 1.609344; }
      return dist;
    }
  }

@Override
public ProblemTable getInProgressRequestDetails(Integer requestId) throws Exception {

	Session session = null;
    session = sessionFactory.getCurrentSession();
    CriteriaBuilder builder = session.getCriteriaBuilder();
    CriteriaQuery<ProblemTableEntity> criteriaQuery= builder.createQuery(ProblemTableEntity.class);
    Root<ProblemTableEntity> root = criteriaQuery.from(ProblemTableEntity.class);
    criteriaQuery.select(root);
    criteriaQuery.where(builder.equal(root.get("requestId"), requestId),builder.equal(root.get("status"), "inProgress"));
    
    try
    {
    ProblemTableEntity pt = session.createQuery(criteriaQuery).getSingleResult();
    ProblemTable p=new ProblemTable();
    if(pt!=null)
    {
	p.setEstimatedCost(pt.getEstimatedCost());
	p.setLocation(pt.getLocation());
	p.setProbdescr(pt.getProbdescr());
	p.setRequestId(pt.getRequestId());
	p.setSeekerId(pt.getSeekerId());
	p.setVehnum(pt.getVehnum());
	p.setVmanuf(pt.getVmanuf());
	p.setVmodel(pt.getVmodel());
	p.setVproblem(pt.getVproblem());
	p.setVtype(pt.getVtype());
	p.setStatus(pt.getStatus());
	p.setProviderId(pt.getProviderId());
    }
	return p;
    }
    catch(Exception ex)
    {
    	throw new Exception("No Such Data with Status Open");
    }
    
    
}

@Override
public List<String>get_problem_name(String vehicleType){

    
    
    Session session = null;
    session = sessionFactory.getCurrentSession();

    CriteriaBuilder builder = session.getCriteriaBuilder();
    CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);

    Root<ProblemCostEntity> root = criteriaQuery.from(ProblemCostEntity.class);
    criteriaQuery.select(root.get("probType"));
    criteriaQuery.where(builder.equal(root.get("vehicleType"), vehicleType));

    List<String> nameList = session.createQuery(criteriaQuery).list();
    return nameList;
      
}

@Override
public ServiceSeeker get_seeker_contact_details(String seekerid)
{
	ServiceSeeker s=new ServiceSeeker();
	
	Session session = sessionFactory.getCurrentSession();
	ServiceSeekerEntity se = (ServiceSeekerEntity) session.get(ServiceSeekerEntity.class,seekerid);
    
	//System.out.println(se.getUserId());
	if(se!=null)
    {
    	
    
	s.setPassword(se.getPassword());
     s.setUserId(se.getUserId());
     s.setAnswer(se.getAnswer());
     s.setName(se.getName());
     s.setPhoneNumber(se.getPhoneNumber());
     s.setQuestion(se.getQuestion());
    
     return s;
     }
	else
	
    
    
    	return null;
    
    
    
    
	
}

@Override
public ServiceProvider get_provider_contact_details(String providerId) {
	ServiceProvider s=new ServiceProvider();
	
	Session session = sessionFactory.getCurrentSession();
	ServiceProviderEntity se = (ServiceProviderEntity) session.get(ServiceProviderEntity.class,providerId);
    
	//System.out.println(se.getUserId());
	if(se!=null)
    {
	 s.setPassword(se.getPassword());
     s.setUserId(se.getUserId());
     s.setAnswer(se.getAnswer());
     s.setName(se.getName());
     s.setPhoneNumber(se.getPhoneNumber());
     s.setQuestion(se.getQuestion());
     return s;
     }
	else
    	return null;
    
    
    
    
	
}

@Override
public ProviderLocation get_provider_location(String providerId) {
	ProviderLocation pl=new ProviderLocation();
	
	Session session = sessionFactory.getCurrentSession();
	ProviderLocationEntity ple = (ProviderLocationEntity) session.get(ProviderLocationEntity.class,providerId);
    
	//System.out.println(se.getUserId());
	if(ple!=null)
    {
	 pl.setLocation(ple.getLocation());
     pl.setProviderId(ple.getProviderId());
     
     return pl;
     }
	else
    	return null;
    
    
    
    
	
}

@Override
public String saveServiceCost(ServiceCost cost) {
		Session session = sessionFactory.getCurrentSession();
		ServiceCostEntity sce = new ServiceCostEntity();
	    sce.setRequestId(cost.getRequestId());
	    sce.setEstimatedCost(cost.getEstimatedCost());
	    sce.setDistanceTravelled(cost.getDistanceTravelled());
	    sce.setTotalCost(String.valueOf(Float.parseFloat(cost.getEstimatedCost())+Float.parseFloat(cost.getTravelCharge())));
	    sce.setSeekerId(cost.getSeekerId());
	    sce.setTravelCharge(cost.getTravelCharge());
	    sce.setProviderId(cost.getProviderId());
//	    System.out.println(cost.getEstimatedCost());
	    session.persist(sce);
	    return (cost.getRequestId());

	}

@Override
public ServiceCost get_service_cost(String requestId) {
	ServiceCost sc=new ServiceCost();
	
	Session session = sessionFactory.getCurrentSession();
	ServiceCostEntity sce = (ServiceCostEntity) session.get(ServiceCostEntity.class,requestId);
    
	//System.out.println(se.getUserId());
	if(sce!=null)
    {
     sc.setProviderId(sce.getProviderId());
     sc.setDistanceTravelled(sce.getDistanceTravelled());
     sc.setEstimatedCost(sce.getEstimatedCost());
     sc.setRequestId(sce.getRequestId());
     sc.setTravelCharge(sce.getTravelCharge());
     sc.setSeekerId(sce.getSeekerId());
     sc.setTotalCost(sce.getTotalCost());
     return sc;
     }
	else
    	return null;
}

@Override
public List<AvailedServices> getPreAvailed_SeekerDetails(String seekerId) {
	// TODO Auto-generated method stub
	Session session = sessionFactory.getCurrentSession();
	List<ProblemTableEntity> allrequests = null;
	CriteriaBuilder builder = session.getCriteriaBuilder();
    CriteriaQuery<ProblemTableEntity> criteriaQuery= builder.createQuery(ProblemTableEntity.class);
    Root<ProblemTableEntity> root = criteriaQuery.from(ProblemTableEntity.class);
    criteriaQuery.select(root);
    criteriaQuery.where(builder.equal(root.get("seekerId"),seekerId));
	allrequests = session.createQuery(criteriaQuery).list();
	List<AvailedServices> requestAvailed = new ArrayList<AvailedServices>();
	Map< Integer, AvailedServices> itemMap = new TreeMap< Integer, AvailedServices>().descendingMap();
	
	for (ProblemTableEntity i : allrequests) 
	{	
		ServiceCostEntity sce=null;
		CriteriaBuilder build1 = session.getCriteriaBuilder();
	    CriteriaQuery<ServiceCostEntity> criteriaq1= build1.createQuery(ServiceCostEntity.class);
	    Root<ServiceCostEntity> root1 = criteriaq1.from(ServiceCostEntity.class);
	    criteriaq1.select(root1);
	    //System.out.print(i.getRequestId().toString());
	    criteriaq1.where(build1.equal(root1.get("requestId"), i.getRequestId().toString()));
	    
	    ServiceProviderEntity see=null;
		CriteriaBuilder build2 = session.getCriteriaBuilder();
	    CriteriaQuery<ServiceProviderEntity> criteriaq2= build2.createQuery(ServiceProviderEntity.class);
	    Root<ServiceProviderEntity> root2 = criteriaq2.from(ServiceProviderEntity.class);
	    criteriaq2.select(root2);
	    criteriaq2.where(build1.equal(root2.get("userId"), i.getProviderId()));
	    
	    try
	    {
	    sce = session.createQuery(criteriaq1).getSingleResult();
	    see = session.createQuery(criteriaq2).getSingleResult();
	    }
	    catch(Exception ex)
	    {
	    	;
	    }
	    finally
	    {
			
			AvailedServices as = new AvailedServices();
			as.setVproblem(i.getVproblem());
			as.setProbdescr(i.getProbdescr());
			as.setVehnum(i.getVehnum());
			as.setVtype(i.getVtype());
			as.setVmodel(i.getVmodel());
			as.setVmanuf(i.getVmanuf());
			as.setEstimatedCost(i.getEstimatedCost());
			as.setSeekerId(i.getSeekerId());
			as.setProviderId(i.getProviderId());
			as.setRequestId(i.getRequestId().toString());
			as.setTotalCost("<Service Open>");
			as.setReqDateTime(i.getReqDateTime());
			as.setRating(i.getRating());
			if(sce!=null)
			{
				as.setTotalCost(sce.getTotalCost());	
			}
			as.setStatus(i.getStatus());
			as.setLocation(i.getLocation());
			as.setuName("<Service Open>");
			if(see!=null)
			{
				as.setuName(see.getName());
			}
//			requestAvailed.add(as);
			itemMap.put(i.getRequestId(), as);
	    }
	}
	Collection<AvailedServices> values = itemMap.values();
	if(!values.isEmpty())
	 {for(AvailedServices val : values){
		 
		 requestAvailed.add(val);
	 }}
		return requestAvailed;
		
	
	
}

@Override
public List<AvailedServices> getPreAvailed_ProviderDetails(String providerId) {
	
	Session session = sessionFactory.getCurrentSession();
	List<ProblemTableEntity> allrequests = null;
	CriteriaBuilder builder = session.getCriteriaBuilder();
    CriteriaQuery<ProblemTableEntity> criteriaQuery= builder.createQuery(ProblemTableEntity.class);
    Root<ProblemTableEntity> root = criteriaQuery.from(ProblemTableEntity.class);
    criteriaQuery.select(root);
    criteriaQuery.where(builder.equal(root.get("providerId"),providerId));
	allrequests = session.createQuery(criteriaQuery).list();
	List<AvailedServices> requestAvailed = new ArrayList<AvailedServices>();
	Map< Integer, AvailedServices> itemMap = new TreeMap< Integer, AvailedServices>().descendingMap();
	
	for (ProblemTableEntity i : allrequests) 
	{	
		ServiceCostEntity sce=null;
		CriteriaBuilder build1 = session.getCriteriaBuilder();
	    CriteriaQuery<ServiceCostEntity> criteriaq1= build1.createQuery(ServiceCostEntity.class);
	    Root<ServiceCostEntity> root1 = criteriaq1.from(ServiceCostEntity.class);
	    criteriaq1.select(root1);
	    //System.out.print(i.getRequestId().toString());
	    criteriaq1.where(build1.equal(root1.get("requestId"), i.getRequestId().toString()));
	    
	    ServiceSeekerEntity see=null;
		CriteriaBuilder build2 = session.getCriteriaBuilder();
	    CriteriaQuery<ServiceSeekerEntity> criteriaq2= build2.createQuery(ServiceSeekerEntity.class);
	    Root<ServiceSeekerEntity> root2 = criteriaq2.from(ServiceSeekerEntity.class);
	    criteriaq2.select(root2);
	    criteriaq2.where(build1.equal(root2.get("userId"), i.getSeekerId()));
	    
	    try
	    {
	    sce = session.createQuery(criteriaq1).getSingleResult();
	    see = session.createQuery(criteriaq2).getSingleResult();
	    }
	    catch(Exception ex)
	    {
	    	;
	    }
	    finally
	    {
			
			AvailedServices as = new AvailedServices();
			as.setVproblem(i.getVproblem());
			as.setProbdescr(i.getProbdescr());
			as.setVehnum(i.getVehnum());
			as.setVtype(i.getVtype());
			as.setVmodel(i.getVmodel());
			as.setVmanuf(i.getVmanuf());
			as.setEstimatedCost(i.getEstimatedCost());
			as.setSeekerId(i.getSeekerId());
			as.setProviderId(i.getProviderId());
			as.setReqDateTime(i.getReqDateTime());
			as.setRequestId(i.getRequestId().toString());
			as.setRating(i.getRating());
			as.setTotalCost("<Service Open>");
			if(sce!=null)
			{
				as.setTotalCost(sce.getTotalCost());	
			}
			as.setStatus(i.getStatus());
			as.setLocation(i.getLocation());
			as.setuName("<Service Open>");
			if(see!=null)
			{
				as.setuName(see.getName());
			}
			itemMap.put(i.getRequestId(), as);
//			requestAvailed.add(as);

	    }
	}
	
	Collection<AvailedServices> values = itemMap.values();
	if(!values.isEmpty())
	 {for(AvailedServices val : values){
		 
		 requestAvailed.add(val);
	 }}
		return requestAvailed;
		
	
	
}

@Override
public List<ProblemTable> getAssistRequestDetails(ProviderLocation proLoc)  {
	// TODO Auto-generated method stub
	
	//Specify the RANGE for Displacement 
	Double range=10.0;
	
	String lat=proLoc.getLocation().split("\\|")[0];
	String lon=proLoc.getLocation().split("\\|")[1];
	Double x1 =Double.parseDouble(lat);
	Double y1=Double.parseDouble(lon);
	Map< Double, ProblemTable> itemMap = new TreeMap< Double, ProblemTable>();
	
	Session session = sessionFactory.getCurrentSession();
	List<ProblemTableEntity> allrequests = null;
	CriteriaBuilder builder = session.getCriteriaBuilder();
    CriteriaQuery<ProblemTableEntity> criteriaQuery= builder.createQuery(ProblemTableEntity.class);
    Root<ProblemTableEntity> root = criteriaQuery.from(ProblemTableEntity.class);
    criteriaQuery.select(root);
    criteriaQuery.where(builder.equal(root.get("status"), "open"));
	Double dist;
		allrequests = session.createQuery(criteriaQuery).list();
		
		
		
		List <ProblemTable>request = new ArrayList<ProblemTable>();
		double counter=0.0;
		for (ProblemTableEntity i : allrequests) {
			
			
			Double x2 =Double.parseDouble(i.getLocation().split("\\|")[0]);
			Double y2 =Double.parseDouble(i.getLocation().split("\\|")[1]);
			dist=distance(x1,y1,x2,y2);
			System.out.println(dist+" "+i.getRequestId());
			if(dist<range)
			{	
				counter=counter+0.0111;
				ProblemTable p = new ProblemTable();
				p.setEstimatedCost(i.getEstimatedCost());
				p.setLocation(i.getLocation());
				p.setProbdescr(i.getProbdescr());
				p.setRequestId(i.getRequestId());
				p.setSeekerId(i.getSeekerId());
				p.setVehnum(i.getVehnum());
				p.setVmanuf(i.getVmanuf());
				p.setVmodel(i.getVmodel());
				p.setVproblem(i.getVproblem());
				p.setVtype(i.getVtype());
				p.setStatus(i.getStatus());
				p.setProviderId(i.getProviderId());
				p.setDistance(dist.toString().substring(0, dist.toString().indexOf(".")+3));
				System.out.println(p.getDistance());
				itemMap.put(dist+counter, p);
//				request.add(p);
			}
		}
		
		Collection<ProblemTable> values = itemMap.values();
		if(!values.isEmpty())
		 {for(ProblemTable val : values){
			 
			 request.add(val);
		 }}

		return request;
		
	
	
}

@Override
public UserRating set_userRating(UserRating rating) {
	
	UserRating newRating=new UserRating();
	Session session = sessionFactory.getCurrentSession();
	Float ratingValue=(float) ((Integer.parseInt(rating.getRate1())+
					  Integer.parseInt(rating.getRate2())+
					  Integer.parseInt(rating.getRate3()))/3);
	
	ServiceProviderEntity spe=null;
	CriteriaBuilder build1 = session.getCriteriaBuilder();
    CriteriaQuery<ServiceProviderEntity> criteriaq1= build1.createQuery(ServiceProviderEntity.class);
    Root<ServiceProviderEntity> root1 = criteriaq1.from(ServiceProviderEntity.class);
    criteriaq1.select(root1);
    //System.out.print(i.getRequestId().toString());
    criteriaq1.where(build1.equal(root1.get("userId"), rating.getProviderId()));
    try
    {
    spe = session.createQuery(criteriaq1).getSingleResult();
    if(Float.parseFloat(spe.getRating())>0.0)
    {
    ratingValue=(ratingValue+Float.parseFloat(spe.getRating()))/2;
    }
//    System.out.println(ratingValue.toString());
//    System.out.println(rating.getProviderId());
    ServiceProviderEntity ste= session.get(ServiceProviderEntity.class,rating.getProviderId());
    if(	ste !=null) {
    ste.setRating(ratingValue.toString());
    }
    ProblemTableEntity pte= session.get(ProblemTableEntity.class,Integer.parseInt(rating.getRequestId()));
    pte.setRating(rating.getRate1()+"+"+rating.getRate2()+"+"+rating.getRate3());

    return rating;
    }
    catch(Exception ex)
    {
//    	System.err.println(ex.getMessage());
    	return null;
    } 
	
}

@Override
public SiteFeedBack addFeedback(SiteFeedBack fb) {
	Session session = sessionFactory.getCurrentSession();
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MMM/yyyy HH:mm a");
	LocalDateTime now = LocalDateTime.now();
	SiteFeedBackEntity sfbe = new SiteFeedBackEntity();
		
		sfbe.setDateTime(dtf.format(now).toString());
		sfbe.setBestFeature(fb.getBestFeature());
		sfbe.setEaseOfAccess(fb.getEaseOfAccess());
		sfbe.setEmail(fb.getEmail());
		sfbe.setImprove(fb.getImprove());
		sfbe.setOther(fb.getOther());
		sfbe.setRating(fb.getRating());
		sfbe.setRecommendation(fb.getRecommendation());
		sfbe.setUserName(fb.getUserName());
        
        session.persist(sfbe);
        return fb;
	
}
}

		
		
		
		/*Session session = sessionFactory.getCurrentSession();
		AadharCardEntity aadharCardEntity = session.get(AadharCardEntity.class, aadharNumber);
		if(	aadharCardEntity !=null) {
			AadharCard aadharCard = new AadharCard();
			aadharCard.setAadharNumber(aadharCardEntity.getAadharNumber());
			aadharCard.setAddress(aadharCardEntity.getAddress());
			aadharCard.setDateOfBirth(aadharCardEntity.getDateOfBirth());
			aadharCard.setName(aadharCardEntity.getName());
			aadharCard.setPhoneNumber(aadharCardEntity.getPhoneNumber());
			return aadharCard;
		}
		return null;
		
	}

	/*@Override
	public AadharCard updatePhoneNumber(AadharCard aadhar) {
		Session session = sessionFactory.getCurrentSession();
		AadharCardEntity aadharCardEntity = session.get(AadharCardEntity.class, aadhar.getAadharNumber());
		if(	aadharCardEntity !=null) {
			aadharCardEntity.setPhoneNumber(aadhar.getPhoneNumber());
			return aadhar;
		}
		return null;
	}
*/
	

