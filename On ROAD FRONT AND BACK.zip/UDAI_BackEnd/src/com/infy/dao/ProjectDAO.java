package com.infy.dao;

import java.util.List;

import com.infy.model.AvailedServices;
import com.infy.model.ProblemTable;
import com.infy.model.ProviderLocation;
import com.infy.model.ProviderStatus;
import com.infy.model.ServiceCost;
import com.infy.model.ServiceProvider;
//import com.infy.model.AadharCard;
import com.infy.model.ServiceSeeker;
import com.infy.model.SiteFeedBack;
import com.infy.model.UserRating;




public interface ProjectDAO {
	
	
	public String addSeeker(ServiceSeeker seeker);
	
	public ServiceSeeker seeker_login(ServiceSeeker seeker);
	
	public String addProvider(ServiceProvider provider);
	
	public ServiceProvider provider_login(ServiceProvider provider);
	
	public ServiceSeeker seeker_forget_password(ServiceSeeker seeker);

	public ServiceSeeker seeker_update_password(ServiceSeeker seeker);
	
	
	public ServiceProvider provider_forget_password(ServiceProvider provider);

	public ServiceProvider provider_update_password(ServiceProvider provider);
	public ServiceSeeker seeker_update_phoneno(ServiceSeeker seeker);
	//public AadharCard getAadhar(String aadharNumber);

	public List<String> getCompanyName(String vehicleType) throws Exception;

	public List<String> getModelName(String companyName) throws Exception;

	public List<String> get_problem_name(String vehicleType);

	public String getEstimatedCost(String vehicleType,String probType);
	
	

	public Integer savesAssistRequest(ProblemTable table);

	public String setStatus(ProviderStatus ps);

//	public List<ProblemTable> getAssistRequestDetails();

	public ProblemTable provider_modify_cost(ProblemTable req);

	public ServiceSeeker seeker_update_name(ServiceSeeker seeker);

	

	public String setProviderLocation(ProviderLocation l);
	public ServiceProvider provider_update_name(ServiceProvider provider);
	public ServiceProvider provider_update_phoneno(ServiceProvider provider);
	//public AadharCard updatePhoneNumber(AadharCard aadhar);

	public List<String> getNearestProvider(ProblemTable table);

	 public ServiceSeeker seeker_reset_password(ServiceSeeker seeker);

	public ServiceProvider provider_reset_password(ServiceProvider provider);
	public ServiceSeeker get_seeker_contact_details(String seekerid) throws Exception;
	public ProblemTable set_request_status(ProblemTable problem);
	public ProblemTable set_request_providerServiced(ProblemTable problem);

	public ProblemTable getInProgressRequestDetails(Integer requestId) throws Exception;

	public ServiceProvider get_provider_contact_details(String providerId);

	public ProviderLocation get_provider_location(String providerId);

	public String saveServiceCost(ServiceCost cost);

	public ServiceCost get_service_cost(String requestId);

	public List<AvailedServices> getPreAvailed_SeekerDetails(String seekerId);

	public List<AvailedServices> getPreAvailed_ProviderDetails(String providerId);

	public UserRating set_userRating(UserRating rating);

	List<ProblemTable> getAssistRequestDetails(ProviderLocation proLoc);

	public SiteFeedBack addFeedback(SiteFeedBack feedBack);

}
