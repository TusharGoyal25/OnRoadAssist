package com.infy.model;

public class ProviderStatus {
       private String providerId;
       private String status;
       private String message;
       public String getMessage() {
              return message;
       }
       public void setMessage(String message) {
              this.message = message;
       }
       public String getProviderId() {
              return providerId;
       }
       public void setProviderId(String providerId) {
              this.providerId = providerId;
       }
       public String getStatus() {
              return status;
       }
       public void setStatus(String status) {
              this.status = status;
       }}
