package com.infy.model;

public class AvailedServices {
	
	private String vproblem ;
    private String probdescr ;
    private String vehnum;
    private String vtype;
    private String vmodel;
    private String vmanuf;
    private String estimatedCost;
    private String seekerId;
    private String providerId;
    private String requestId;
    private String uName;
    private String totalCost;
    private String status;
    private String location;
    private String reqDateTime;
    private String rating;
    
	public String getVproblem() {
		return vproblem;
	}
	public void setVproblem(String vproblem) {
		this.vproblem = vproblem;
	}
	public String getProbdescr() {
		return probdescr;
	}
	public void setProbdescr(String probdescr) {
		this.probdescr = probdescr;
	}
	public String getVehnum() {
		return vehnum;
	}
	public void setVehnum(String vehnum) {
		this.vehnum = vehnum;
	}
	public String getVtype() {
		return vtype;
	}
	public void setVtype(String vtype) {
		this.vtype = vtype;
	}
	public String getVmodel() {
		return vmodel;
	}
	public void setVmodel(String vmodel) {
		this.vmodel = vmodel;
	}
	public String getVmanuf() {
		return vmanuf;
	}
	public void setVmanuf(String vmanuf) {
		this.vmanuf = vmanuf;
	}
	public String getEstimatedCost() {
		return estimatedCost;
	}
	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}
	public String getSeekerId() {
		return seekerId;
	}
	public void setSeekerId(String seekerId) {
		this.seekerId = seekerId;
	}
	public String getProviderId() {
		return providerId;
	}
	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getReqDateTime() {
		return reqDateTime;
	}
	public void setReqDateTime(String reqDateTime) {
		this.reqDateTime = reqDateTime;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
    
 
}
