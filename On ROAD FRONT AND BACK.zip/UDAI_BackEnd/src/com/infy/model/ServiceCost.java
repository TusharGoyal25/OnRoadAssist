package com.infy.model;

public class ServiceCost {
	
	private String requestId;
	private String providerId;
	private String seekerId;
	private String estimatedCost;
	private String distanceTravelled;
	private String travelCharge;
	private String totalCost;
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getProviderId() {
		return providerId;
	}
	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	public String getSeekerId() {
		return seekerId;
	}
	public void setSeekerId(String seekerId) {
		this.seekerId = seekerId;
	}
	public String getEstimatedCost() {
		return estimatedCost;
	}
	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}
	public String getDistanceTravelled() {
		return distanceTravelled;
	}
	public void setDistanceTravelled(String distanceTravelled) {
		this.distanceTravelled = distanceTravelled;
	}
	public String getTravelCharge() {
		return travelCharge;
	}
	public void setTravelCharge(String travelCharge) {
		this.travelCharge = travelCharge;
	}
	public String getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}
	

}
