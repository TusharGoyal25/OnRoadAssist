package com.infy.model;

public class ProblemCost {
	
	
	
	private String probType;
	private String vehicleType;
	private String estimatedCost;
	private String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getProbType() {
		return probType;
	}
	public void setProbType(String probType) {
		this.probType = probType;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getEstimatedCost() {
		return estimatedCost;
	}
	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}

}
