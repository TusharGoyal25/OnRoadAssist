package com.infy.api;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.AvailedServices;
import com.infy.model.ProblemTable;
import com.infy.model.ProviderLocation;
import com.infy.model.ProviderStatus;
import com.infy.model.ServiceCost;
import com.infy.model.ServiceProvider;
import com.infy.model.ServiceSeeker;
import com.infy.model.SiteFeedBack;
import com.infy.model.UserRating;
import com.infy.service.ProjectService;
import com.infy.service.ProjectServiceImpl;
import com.infy.utility.ContextFactory;

@RestController
@CrossOrigin
@RequestMapping(value="ProjectAPI")
public class ProjectAPI {
	
	private ProjectService service;
	
	@RequestMapping(method=RequestMethod.POST, value="addSeeker")
	
	public ResponseEntity<String> addSeeker(@RequestBody ServiceSeeker seeker){

		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
		
		ResponseEntity<String> responseEntity;
		try {
			String userId = service.addSeeker(seeker);
			responseEntity = new ResponseEntity<String>(userId,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			String s;
			s=(errorMessage);
			responseEntity = new ResponseEntity<String>(s,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}
	
	
	
@RequestMapping(method=RequestMethod.POST, value="seeker_login")
	
	public ResponseEntity<ServiceSeeker> seeker_login(@RequestBody ServiceSeeker seeker){

		Environment environment= ContextFactory.getContext().getEnvironment();
		service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
		ServiceSeeker ss=new ServiceSeeker();
		
		ResponseEntity<ServiceSeeker> responseEntity;
		try {
			
		 ss=service.seeker_login(seeker);
			responseEntity = new ResponseEntity<ServiceSeeker>(ss,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			ss.setMessage(errorMessage);
		
			responseEntity = new ResponseEntity<ServiceSeeker>(ss,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}
@RequestMapping(method=RequestMethod.POST, value="seeker_forget_password")

public ResponseEntity<ServiceSeeker> seeker_forget_password(@RequestBody ServiceSeeker seeker){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	ServiceSeeker ss=new ServiceSeeker();
	
	ResponseEntity<ServiceSeeker> responseEntity;
	try {
		
	 ss=service.seeker_forget_password(seeker);
		responseEntity = new ResponseEntity<ServiceSeeker>(ss,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ss.setMessage(errorMessage);
	
		responseEntity = new ResponseEntity<ServiceSeeker>(ss,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}
	
@RequestMapping(method=RequestMethod.POST, value="seeker_update_password")
public ResponseEntity<ServiceSeeker> seeker_update_password(@RequestBody ServiceSeeker seeker){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ServiceSeeker> responseEntity;
	try {
		ServiceSeeker se= service.seeker_update_password(seeker);
		se.setMessage(environment.getProperty("ProjectAPI.PASS_SUCCESS_UPDATE"));
		responseEntity = new ResponseEntity<ServiceSeeker>(se,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ServiceSeeker fb = new ServiceSeeker();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ServiceSeeker>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}



@RequestMapping(method=RequestMethod.POST, value="addProvider")

public ResponseEntity<String> addProvider(@RequestBody ServiceProvider provider){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<String> responseEntity;
	try {
		String userId = service.addProvider(provider);
		responseEntity = new ResponseEntity<String>(userId,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		String s;
		s=(errorMessage);
		responseEntity = new ResponseEntity<String>(s,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}


@RequestMapping(method=RequestMethod.POST, value="saveFeedback")

public ResponseEntity<SiteFeedBack> saveFeedback(@RequestBody SiteFeedBack feedBack){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<SiteFeedBack> responseEntity;
	try {
		SiteFeedBack sfb = service.saveFeedBack(feedBack);
		responseEntity = new ResponseEntity<SiteFeedBack>(sfb,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		SiteFeedBack sfb =new SiteFeedBack();
		sfb.setUserName(errorMessage);
		responseEntity = new ResponseEntity<SiteFeedBack>(sfb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}



@RequestMapping(method=RequestMethod.POST, value="provider_login")

public ResponseEntity<ServiceProvider> provider_login(@RequestBody ServiceProvider provider){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	ServiceProvider ss=new ServiceProvider();
	
	ResponseEntity<ServiceProvider> responseEntity;
	try {
		
	 ss=service.provider_login(provider);
		responseEntity = new ResponseEntity<ServiceProvider>(ss,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ss.setMessage(errorMessage);
	
		responseEntity = new ResponseEntity<ServiceProvider>(ss,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}

	

@RequestMapping(method=RequestMethod.POST, value="provider_forget_password")

public ResponseEntity<ServiceProvider> provider_forget_password(@RequestBody ServiceProvider provider){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	ServiceProvider ss=new ServiceProvider();
	
	ResponseEntity<ServiceProvider> responseEntity;
	try {
		
	 ss=service.provider_forget_password(provider);
		responseEntity = new ResponseEntity<ServiceProvider>(ss,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ss.setMessage(errorMessage);
	
		responseEntity = new ResponseEntity<ServiceProvider>(ss,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}
	
@RequestMapping(method=RequestMethod.POST, value="provider_update_password")
public ResponseEntity<ServiceProvider> provider_update_password(@RequestBody ServiceProvider provider){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ServiceProvider> responseEntity;
	try {
		ServiceProvider se= service.provider_update_password(provider);
		se.setMessage(environment.getProperty("ProjectAPIP.PASS_SUCCESS_UPDATE"));
		responseEntity = new ResponseEntity<ServiceProvider>(se,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ServiceProvider fb = new ServiceProvider();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ServiceProvider>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}
	
	
	

@RequestMapping(method=RequestMethod.POST, value="seekerupdatePhoneNumber")
public ResponseEntity<ServiceSeeker> updatePhoneNumber(@RequestBody ServiceSeeker seeker){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ServiceSeeker> responseEntity;
	try {
		ServiceSeeker serviceSeeker = service.seeker_update_phoneno(seeker);
		serviceSeeker.setMessage(environment.getProperty("SeekerSERVICEAPI.SUCCESSFULL"));
		responseEntity = new ResponseEntity<ServiceSeeker>(serviceSeeker,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ServiceSeeker fb = new ServiceSeeker();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ServiceSeeker>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}


@RequestMapping(method=RequestMethod.POST, value="setServiceRequestStatus")
public ResponseEntity<ProblemTable> setServiceRequestStatus(@RequestBody ProblemTable problemTable){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ProblemTable> responseEntity;
	try {
		ProblemTable problem = service.setRequestStatus(problemTable);
		problem.setMessage("Service Request Updated");
		responseEntity = new ResponseEntity<ProblemTable>(problem,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = exception.getMessage();
		ProblemTable fb = new ProblemTable();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ProblemTable>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}
	

@RequestMapping(method=RequestMethod.POST, value="setProviderForService")
public ResponseEntity<ProblemTable> setProviderForService(@RequestBody ProblemTable problemTable){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ProblemTable> responseEntity;
	try {
		ProblemTable problem = service.setProviderForService(problemTable);
		problem.setMessage("Service Request Updated");
		responseEntity = new ResponseEntity<ProblemTable>(problem,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = exception.getMessage();
		ProblemTable fb = new ProblemTable();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ProblemTable>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}
	
	@RequestMapping(method=RequestMethod.POST, value="get_company_name")

public ResponseEntity<List<String>> getCompanyName(@RequestBody String vehicleType){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	List<String> cname=new ArrayList<String>();
	
	ResponseEntity<List<String>> responseEntity;
	try {
		
	 cname=service.getCompanyName(vehicleType);
		responseEntity = new ResponseEntity<List<String>>(cname,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		List<String> c=new ArrayList<String>();
		c.add(errorMessage);
	
		responseEntity = new ResponseEntity<List<String>>(c,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}	
	
	
	@RequestMapping(method=RequestMethod.POST, value="getServiceCostDetails")

	public ResponseEntity<ServiceCost> getServiceCostDetails(@RequestBody String requestId){

		Environment environment= ContextFactory.getContext().getEnvironment();
		service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
		ServiceCost cost=new ServiceCost();
		ResponseEntity<ServiceCost> responseEntity;
		try {
			
			cost=service.getServiceCostDetails(requestId);
			responseEntity = new ResponseEntity<ServiceCost>(cost,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = exception.getMessage();
			cost.setRequestId(errorMessage);
			responseEntity = new ResponseEntity<ServiceCost>(cost,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}	
		
	
	@RequestMapping(method=RequestMethod.POST, value="get_model_name")

public ResponseEntity<List<String>> getModelName(@RequestBody String companyName){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	List<String> mname=new ArrayList<String>();
	
	ResponseEntity<List<String>> responseEntity;
	try {
		
	 mname=service.getModelName( companyName);
		responseEntity = new ResponseEntity<List<String>>(mname,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		List<String> m=new ArrayList<String>();
		m.add(errorMessage);
	
		responseEntity = new ResponseEntity<List<String>>(m,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}	
		
	

	@RequestMapping(method=RequestMethod.POST, value="get_problem_name")

public ResponseEntity<List<String>> get_problem_name(@RequestBody String vehicleType){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	List<String> mname=new ArrayList<String>();
	
	ResponseEntity<List<String>> responseEntity;
	try {
		
	 mname=service.get_problem_name(vehicleType);
		responseEntity = new ResponseEntity<List<String>>(mname,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		List<String> m=new ArrayList<String>();
		m.add(errorMessage);
	
		responseEntity = new ResponseEntity<List<String>>(m,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}		
	
	

	@RequestMapping(method=RequestMethod.GET, value="get_estimated_cost")
	//@PostMapping("/get_estimated_cost/{vehicleType}/{probType}")
	public ResponseEntity<String> getEstimatedCost(/*@PathVariable("vehicleType")*/String vehicleType,/*@PathVariable("probType")*/String probType){

		Environment environment= ContextFactory.getContext().getEnvironment();
		service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
		String cost;
		
		ResponseEntity<String> responseEntity;
		try {
			
		 cost=service.getEstimatedCost(vehicleType,probType);
			responseEntity = new ResponseEntity<String>(cost,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			String m=errorMessage;
		
		
			responseEntity = new ResponseEntity<String>(m,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}		
		
		
	
	
@RequestMapping(method=RequestMethod.POST, value="saveAssistRequest")
	
	public ResponseEntity<Integer>  saveAssistRequest(@RequestBody ProblemTable table){

		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
		
		ResponseEntity<Integer> responseEntity;
		try {
			Integer userId = service.saveAssistRequest(table);
			responseEntity = new ResponseEntity<Integer>(userId,HttpStatus.OK);

		}

		catch(Exception exception) {
			
			Integer s=404;
			responseEntity = new ResponseEntity<Integer>(s,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}

@RequestMapping(method=RequestMethod.POST, value="saveServiceCostDetails")
public ResponseEntity<String>  saveServiceCostDetails(@RequestBody ServiceCost cost){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<String> responseEntity;
	try {
		
		String requestId = service.saveServiceCostDetails(cost);
		responseEntity = new ResponseEntity<String>(requestId,HttpStatus.OK);

	}

	catch(Exception exception) {
		
		String s="404";
		responseEntity = new ResponseEntity<String>(s,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}

	
@RequestMapping(method=RequestMethod.POST, value="setStatus")

public ResponseEntity<String> setStatus(@RequestBody ProviderStatus p){

       Environment environment= ContextFactory.getContext().getEnvironment();
       
       service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
       
       ResponseEntity<String> responseEntity;
       try {
              String s= service.setStatus(p);
              responseEntity = new ResponseEntity<String>(s,HttpStatus.OK);

       }

       catch(Exception exception) {
              String errorMessage = environment.getProperty(exception.getMessage());
              String s;
              s=(errorMessage);
              responseEntity = new ResponseEntity<String>(s,HttpStatus.BAD_REQUEST);

       }

       return responseEntity;

}


	
@RequestMapping(method=RequestMethod.POST, value="getAssistRequestDetails")
public ResponseEntity<List<ProblemTable>> getAssistRequestDetails(@RequestBody ProviderLocation providerLocation){
	
	Environment environment= ContextFactory.getContext().getEnvironment();
	ResponseEntity<List<ProblemTable>> responseEntity=null;

	List<ProblemTable> t = new ArrayList<ProblemTable>();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	try {
		t=service.getAssistRequestDetails(providerLocation);
		responseEntity = new ResponseEntity<>(t,HttpStatus.OK);

	}


	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
ProblemTable table = new ProblemTable();
		table.setMessage(errorMessage);			
		t.add(table);
			
		responseEntity = new ResponseEntity<>(t,HttpStatus.BAD_REQUEST);
		

	}

	return responseEntity;

}
	
@RequestMapping(method=RequestMethod.POST, value="getPreAvailed_Seeker")
public ResponseEntity<List<AvailedServices>> getPreAvailed_Seeker(@RequestBody String seekerId){
	
	Environment environment= ContextFactory.getContext().getEnvironment();
	ResponseEntity<List<AvailedServices>> responseEntity=null;

	List<AvailedServices> t = new ArrayList<AvailedServices>();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	try {
		t=service.getPreAvailed_Seeker(seekerId);
		responseEntity = new ResponseEntity<>(t,HttpStatus.OK);

	}


	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		AvailedServices table = new AvailedServices();
		table.setProbdescr(errorMessage);			
		t.add(table);
			
		responseEntity = new ResponseEntity<>(t,HttpStatus.BAD_REQUEST);
		

	}

	return responseEntity;

}


@RequestMapping(method=RequestMethod.POST, value="getPreAvailed_Provider")
public ResponseEntity<List<AvailedServices>> getPreAvailed_Provider(@RequestBody String providerId){

Environment environment= ContextFactory.getContext().getEnvironment();
ResponseEntity<List<AvailedServices>> responseEntity=null;

List<AvailedServices> t = new ArrayList<AvailedServices>();
service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);

try {
	t=service.getPreAvailed_Provider(providerId);
	responseEntity = new ResponseEntity<>(t,HttpStatus.OK);

}


catch(Exception exception) {
	String errorMessage = environment.getProperty(exception.getMessage());
	AvailedServices table = new AvailedServices();
	table.setProbdescr(errorMessage);			
	t.add(table);
		
	responseEntity = new ResponseEntity<>(t,HttpStatus.BAD_REQUEST);
	

}

return responseEntity;

}


@RequestMapping(method=RequestMethod.POST, value="seekerupdatename")
public ResponseEntity<ServiceSeeker> updateName(@RequestBody ServiceSeeker seeker){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ServiceSeeker> responseEntity;
	try {
		ServiceSeeker serviceSeeker = service.seeker_update_name(seeker);
		serviceSeeker.setMessage(environment.getProperty("Seeker.SUCCESSFULL"));
		responseEntity = new ResponseEntity<ServiceSeeker>(serviceSeeker,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ServiceSeeker fb = new ServiceSeeker();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ServiceSeeker>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}




@RequestMapping(method=RequestMethod.POST, value="seeker_reset_password")
public ResponseEntity<ServiceSeeker> seeker_reset_password(@RequestBody ServiceSeeker seeker){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ServiceSeeker> responseEntity;
	try {
		ServiceSeeker se= service.seeker_reset_password(seeker);
		se.setMessage(environment.getProperty("ProjectAPI.PASS_SUCCESS_UPDATE"));
		responseEntity = new ResponseEntity<ServiceSeeker>(se,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ServiceSeeker fb = new ServiceSeeker();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ServiceSeeker>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}

@RequestMapping(method=RequestMethod.POST, value="provider_reset_password")
public ResponseEntity<ServiceProvider> provider_reset_password(@RequestBody ServiceProvider provider){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ServiceProvider> responseEntity;
	try {
		ServiceProvider se= service.provider_reset_password(provider);
		se.setMessage(environment.getProperty("ProjectAPI.PASS_SUCCESS_UPDATE"));
		responseEntity = new ResponseEntity<ServiceProvider>(se,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ServiceProvider fb = new ServiceProvider();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ServiceProvider>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}
	

@RequestMapping(method=RequestMethod.POST, value="setProviderLocation")

public ResponseEntity<String> setProviderLocation(@RequestBody ProviderLocation l){

       Environment environment= ContextFactory.getContext().getEnvironment();
       
       service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
       
       ResponseEntity<String> responseEntity;
       try {
              String s= service.setProviderLocation(l);
              responseEntity = new ResponseEntity<String>(s,HttpStatus.OK);

       }

       catch(Exception exception) {
              String errorMessage = environment.getProperty(exception.getMessage());
              String s;
              s=(errorMessage);
              responseEntity = new ResponseEntity<String>(s,HttpStatus.BAD_REQUEST);

       }

       return responseEntity;

}

@RequestMapping(method=RequestMethod.POST, value="providerupdatename")
public ResponseEntity<ServiceProvider> updateName(@RequestBody ServiceProvider provider){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ServiceProvider> responseEntity;
	try {
		ServiceProvider serviceProvider = service.provider_update_name(provider);
		serviceProvider.setMessage(environment.getProperty("Providerupdatename.SUCCESSFULL"));
		responseEntity = new ResponseEntity<ServiceProvider>(serviceProvider,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ServiceProvider fb = new ServiceProvider();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ServiceProvider>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}

@RequestMapping(method=RequestMethod.POST, value="providerupdatePhoneNumber")
public ResponseEntity<ServiceProvider> providerupdatePhoneNumber(@RequestBody ServiceProvider provider){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<ServiceProvider> responseEntity;
	try {
		ServiceProvider serviceProvider = service.provider_update_phoneno(provider);
		serviceProvider.setMessage(environment.getProperty("Providerupdatephonenumber.SUCCESSFULL"));
		responseEntity = new ResponseEntity<ServiceProvider>(serviceProvider,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ServiceProvider fb = new ServiceProvider();
		fb.setMessage(errorMessage);
		responseEntity = new ResponseEntity<ServiceProvider>(fb,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}
	

@RequestMapping(method=RequestMethod.POST, value="getNearestProvider")

public ResponseEntity<List<String>> getNearestProvider(@RequestBody ProblemTable p){

       Environment environment= ContextFactory.getContext().getEnvironment();
       
       service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
       List<String> pt = new LinkedList<String>();
       ResponseEntity<List<String>> responseEntity;
       try {	

               pt= service.getNearestProvider(p);
              responseEntity = new ResponseEntity<List<String>>(pt,HttpStatus.OK);

       }

       catch(Exception exception) {
              String errorMessage = environment.getProperty(exception.getMessage());
             
              pt.add(errorMessage);
              responseEntity = new ResponseEntity<List<String>>(pt,HttpStatus.BAD_REQUEST);

       }

       return responseEntity;

}





@RequestMapping(method=RequestMethod.POST, value="get_seeker_contact_details")
public ResponseEntity<ServiceSeeker> get_seeker_contact_details(@RequestBody String seekerid){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	ServiceSeeker ss=new ServiceSeeker();
	
	ResponseEntity<ServiceSeeker> responseEntity;
	try {
		
	 ss=service.get_seeker_contact_details(seekerid);
		responseEntity = new ResponseEntity<ServiceSeeker>(ss,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());
		ss.setMessage(errorMessage);
	
		responseEntity = new ResponseEntity<ServiceSeeker>(ss,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}



@RequestMapping(method=RequestMethod.POST, value="get_provider_contact_details")
public ResponseEntity<ServiceProvider> get_provider_contact_details(@RequestBody String providerId){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	ServiceProvider ss=new ServiceProvider();
	
	ResponseEntity<ServiceProvider> responseEntity;
	try {
		
	 ss=service.get_provider_contact_details(providerId);
	 responseEntity = new ResponseEntity<ServiceProvider>(ss,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = exception.getMessage();
		ss.setMessage(errorMessage);
	
		responseEntity = new ResponseEntity<ServiceProvider>(ss,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}


@RequestMapping(method=RequestMethod.POST, value="get_provider_location")
public ResponseEntity<ProviderLocation> get_provider_location(@RequestBody String providerId){

	Environment environment= ContextFactory.getContext().getEnvironment();
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	ProviderLocation ss=new ProviderLocation();
	
	ResponseEntity<ProviderLocation> responseEntity;
	try {
		
	 ss=service.get_provider_location(providerId);
	 responseEntity = new ResponseEntity<ProviderLocation>(ss,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = exception.getMessage();
		ss.setLocation(errorMessage);
		responseEntity = new ResponseEntity<ProviderLocation>(ss,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

}

@RequestMapping(method=RequestMethod.POST, value="modify_cost")

public ResponseEntity<ProblemTable> provider_modify_cost(@RequestBody ProblemTable p){

       Environment environment= ContextFactory.getContext().getEnvironment();
       
       service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
       
       ResponseEntity<ProblemTable> responseEntity;
       try {
    	   ProblemTable s= service.provider_modify_cost(p);
              responseEntity = new ResponseEntity<ProblemTable>(s,HttpStatus.OK);

       }

       catch(Exception exception) {
              String errorMessage = environment.getProperty(exception.getMessage());
              String s;
              s=(errorMessage);
              ProblemTable pt=new ProblemTable();
              pt.setMessage(s);
              responseEntity = new ResponseEntity<ProblemTable>(pt,HttpStatus.BAD_REQUEST);

       }

       return responseEntity;

}



@RequestMapping(method=RequestMethod.POST, value="saveUsersRating")
public ResponseEntity<UserRating>  saveUsersRating(@RequestBody UserRating rating){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	ResponseEntity<UserRating> responseEntity;
    try {
    		UserRating urs= service.saveUserRating(rating);
           responseEntity = new ResponseEntity<UserRating>(urs,HttpStatus.OK);

    }

    catch(Exception exception) {
           String errorMessage = exception.getMessage();
           UserRating urs=new UserRating();
           urs.setRate1(errorMessage);;
           responseEntity = new ResponseEntity<UserRating>(urs,HttpStatus.BAD_REQUEST);

    }

    return responseEntity;

}


@RequestMapping(method=RequestMethod.POST, value="getApprovedService")
public ResponseEntity<ProblemTable>  getApprovedService(@RequestBody String reqId){

	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (ProjectService) ContextFactory.getContext().getBean(ProjectServiceImpl.class);
	
	Integer requestId=Integer.parseInt(reqId);
	ResponseEntity<ProblemTable> responseEntity;
    try {
 	   	   ProblemTable s= service.getInProgressRequest(requestId);
           responseEntity = new ResponseEntity<ProblemTable>(s,HttpStatus.OK);

    }

    catch(Exception exception) {
           String errorMessage = exception.getMessage();
           ProblemTable pt=new ProblemTable();
           pt.setMessage(errorMessage);
           pt.setStatus("open");
           pt.setRequestId(requestId);
           responseEntity = new ResponseEntity<ProblemTable>(pt,HttpStatus.BAD_REQUEST);

    }

    return responseEntity;

}


}
	