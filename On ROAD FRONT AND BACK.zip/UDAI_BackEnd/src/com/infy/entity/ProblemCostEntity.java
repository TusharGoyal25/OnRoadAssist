package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "ProblemCost")
public class ProblemCostEntity {
      
	@Id
	private String probType;
	private String vehicleType;
	private String estimatedCost;
	public String getProbType() {
		return probType;
	}
	public void setProbType(String probType) {
		this.probType = probType;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getEstimatedCost() {
		return estimatedCost;
	}
	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}
	
	
 	
	
	
	

}
