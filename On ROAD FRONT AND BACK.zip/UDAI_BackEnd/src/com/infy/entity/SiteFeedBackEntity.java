package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SiteFeedBack")
public class SiteFeedBackEntity {
	
	@Id
	private String email;
	private String userName;
	private String easeOfAccess;
	private String bestFeature;
	private String rating;
	private String improve;
	private String recommendation;
	private String other;
	private String dateTime;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEaseOfAccess() {
		return easeOfAccess;
	}
	public void setEaseOfAccess(String easeOfAccess) {
		this.easeOfAccess = easeOfAccess;
	}
	public String getBestFeature() {
		return bestFeature;
	}
	public void setBestFeature(String bestFeature) {
		this.bestFeature = bestFeature;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getImprove() {
		return improve;
	}
	public void setImprove(String improve) {
		this.improve = improve;
	}
	public String getRecommendation() {
		return recommendation;
	}
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	
	


}
