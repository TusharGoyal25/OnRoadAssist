package com.infy.service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.ProjectDAO;
import com.infy.model.AvailedServices;
import com.infy.model.ProblemTable;
import com.infy.model.ProviderLocation;
import com.infy.model.ProviderStatus;
import com.infy.model.ServiceCost;
import com.infy.model.ServiceProvider;
import com.infy.model.ServiceSeeker;
import com.infy.model.SiteFeedBack;
import com.infy.model.UserRating;

@Service(value="ProjectService")
@Transactional(readOnly = true)
public class ProjectServiceImpl implements ProjectService {

	
	@Autowired
	private ProjectDAO dao;

	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String addSeeker(ServiceSeeker seeker)throws Exception
	{
		
		String userid;
		
		userid=dao.addSeeker(seeker);

		if(userid == null) {
			throw new Exception("Service.INVALID_SEEKER");
			}
		
		
		return userid;
	}
	
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public ServiceSeeker seeker_login(ServiceSeeker seeker) throws Exception
    {
		ServiceSeeker ss=new ServiceSeeker();
		ss=dao.seeker_login(seeker);
		if(ss==null)
		{
			
			throw new Exception("Service.INVALID_SEEKER");
			
		}
		return ss;
		
		
    }
	
	
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String addProvider(ServiceProvider provider)throws Exception
	{
		
		String userid;
		
		userid=dao.addProvider(provider);

		if(userid == null) {
			throw new Exception("Service.INVALID_PROVIDER");
			}
		
		
		return userid;
	}
	
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public ServiceProvider provider_login(ServiceProvider provider) throws Exception
    {
		ServiceProvider ss=new ServiceProvider();
		ss=dao.provider_login(provider);
		if(ss==null)
		{
			
			throw new Exception("Service.INVALID_PROVIDER");
			
		}
		return ss;
		
		
    }
	
	
	
	
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public ServiceSeeker seeker_forget_password(ServiceSeeker seeker) throws Exception
    {
		ServiceSeeker ss=new ServiceSeeker();
		ss=dao.seeker_forget_password(seeker);
		if(ss==null)
		{
			
			throw new Exception("Service.INVALID_SEEKER");
			
		}
		return ss;
		
		
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public ServiceSeeker seeker_update_password(ServiceSeeker seeker) throws Exception {
		ServiceSeeker se = dao.seeker_update_password(seeker);
		
		if(seeker == null) {
			throw new Exception("Service.INVALID_SEEKER");
		}
		
		return se;
	}
	
	
	
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public ServiceProvider provider_forget_password(ServiceProvider provider) throws Exception
    {
		ServiceProvider ss=new ServiceProvider();
		ss=dao.provider_forget_password(provider);
		if(ss==null)
		{
			
			throw new Exception("Service.INVALID_Provider");
			
		}
		return ss;
		
		
    }
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public ServiceProvider provider_update_password(ServiceProvider provider) throws Exception {
		ServiceProvider se = dao.provider_update_password(provider);
		
		if(provider == null) {
			throw new Exception("Service.INVALID_Provider");
		}
		
		return se;
	}
	
	
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public ServiceSeeker seeker_update_phoneno(ServiceSeeker seeker) throws Exception {
		ServiceSeeker serviceSeeker = dao.seeker_update_phoneno(seeker);
		
		if(serviceSeeker == null) {
			throw new Exception("Service.INVALID_USER_ID");
		}
		
		return serviceSeeker;
	}
	
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public  List<String> getCompanyName(String vehicleType) throws Exception
    {
		List<String> cname=new ArrayList<String>();
		cname=dao.getCompanyName(vehicleType);
		if(cname==null)
		{
			
			throw new Exception("Service.INVALID_SEEKER");
			
		}
		return cname;
		
		
    }
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public  List<String> getModelName(String companyName) throws Exception
    {
		List<String> mname=new ArrayList<String>();
		mname=dao.getModelName(companyName);
		if(mname==null)
		{
			
			throw new Exception("Service.INVALID_SEEKER");
			
		}
		return mname;
		
		
    }
	
	
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public  List<String> get_problem_name(String vehicleType) throws Exception
    {
		List<String> mname=new ArrayList<String>();
		mname=dao.get_problem_name(vehicleType);
		if(mname==null)
		{
			
			throw new Exception("Service.INVALID_SEEKER");
			
		}
		return mname;
		
		
    }
	
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
    public  String getEstimatedCost(String vehicleType,String probType) throws Exception
    {
		String cost;
		cost=dao.getEstimatedCost(vehicleType,probType);
		if(cost==null)
		{
			
			throw new Exception("Service.INVALID_SEEKER");
			
		}
		return cost;
		
		
    }
	
	


@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Integer saveAssistRequest(ProblemTable table)throws Exception
	{
		
		Integer userid;
		
		userid=dao.savesAssistRequest(table);

		if(userid == null) {
			throw new Exception("Service.INVALID_REQUEST");
			}
		
		
		return userid;
	}
	
@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public String setStatus(ProviderStatus ps) throws Exception {
String st;
       st=dao.setStatus(ps);
       
       if(st==null){
              throw new Exception("Service.INVALID_PROVIDER");
       }
       return st;
}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ProblemTable setRequestStatus(ProblemTable problemTable) throws Exception {
ProblemTable pt;
pt=dao.set_request_status(problemTable);
if(pt==null)
{
	  throw new Exception("Unable to Update Status");
}
	
	return pt;
}



	
@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ProblemTable provider_modify_cost(ProblemTable ps) throws Exception {
ProblemTable st;
   st=dao.provider_modify_cost(ps);
   
   if(st==null){
          throw new Exception("Service.INVALID_PROVIDER");
   }
   return st;
}
	
	

@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ServiceSeeker seeker_update_name(ServiceSeeker seeker) throws Exception {
	ServiceSeeker serviceSeeker = dao.seeker_update_name(seeker);
	
	if(serviceSeeker == null) {
		throw new Exception("Service.INVALID_USER_ID");
	}
	
	return serviceSeeker;
}

@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ServiceSeeker seeker_reset_password(ServiceSeeker seeker) throws Exception {
	ServiceSeeker serviceSeeker = dao.seeker_reset_password(seeker);
	
	if(serviceSeeker == null) {
		throw new Exception("Service.INVALID_USER_ID");
	}
	
	return serviceSeeker;
}
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ServiceProvider provider_reset_password(ServiceProvider provider) throws Exception {
	ServiceProvider serviceProvider = dao.provider_reset_password(provider);
	
	if(serviceProvider == null) {
		throw new Exception("Service.INVALID_USER_ID");
	}
	
	return serviceProvider;
}




@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public String setProviderLocation(ProviderLocation l) throws Exception {
String st;
       st=dao.setProviderLocation(l);
       
       if(st==null){
              throw new Exception("Service.INVALID_LOCATION");
       }
       return st;
}

@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ServiceProvider provider_update_name(ServiceProvider provider) throws Exception {
	ServiceProvider serviceProvider = dao.provider_update_name(provider);
	
	if(serviceProvider == null) {
		throw new Exception("Service.INVALID_USER_ID");
	}
	
	return serviceProvider;
}


@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ServiceProvider provider_update_phoneno(ServiceProvider provider) throws Exception {
	ServiceProvider serviceProvider = dao.provider_update_phoneno(provider);
	
	if(serviceProvider == null) {
		throw new Exception("Service.INVALID_USER_ID");
	}
	
	return serviceProvider;
}


@Override
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public List<String> getNearestProvider(ProblemTable table)throws Exception{ 
	List<String> pt = new LinkedList<String>();
	pt=dao.getNearestProvider(table);
	
	if(pt==null){
		throw new Exception("Service.INVALID_PROVIDER");
	}
	return pt;
}
	

@Override
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public ProviderLocation get_provider_location(String providerId)
		throws Exception {
	ProviderLocation pl=new ProviderLocation();
	pl=dao.get_provider_location(providerId);
	if(pl==null)
	{
		
		throw new Exception("Invalid Provider");
		
	}
	return pl;
}

@Override	
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ProblemTable setProviderForService(ProblemTable problemTable) throws Exception {

		ProblemTable serviceProvider = dao.set_request_providerServiced(problemTable);
		
		if(serviceProvider == null) {
			throw new Exception("Unable to Update ProviderId");
		}
		
		return serviceProvider;
	}

@Override
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public ProblemTable getInProgressRequest(Integer requestId) throws Exception {
	// TODO Auto-generated method stub
	ProblemTable pt=new ProblemTable();
	try{
	pt=dao.getInProgressRequestDetails(requestId);
	return pt;
	}
	catch(Exception ex)
	{
		throw new Exception("Request Not Yet Approved");
	}
	

}
@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ServiceSeeker get_seeker_contact_details(String seekerid) throws Exception
{
	ServiceSeeker ss=new ServiceSeeker();
	ss=dao.get_seeker_contact_details(seekerid);
	if(ss==null)
	{
		
		throw new Exception("Service.INVALID_SEEKER");
		
	}
	return ss;
	
	
}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public ServiceProvider get_provider_contact_details(String providerId) throws Exception
 {
	ServiceProvider sp=new ServiceProvider();
	sp=dao.get_provider_contact_details(providerId);
	if(sp==null)
	{
		
		throw new Exception("Invalid Provider");
		
	}
	return sp;
}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public String saveServiceCostDetails(ServiceCost cost) throws Exception {

	
	String message;
	
	message=dao.saveServiceCost(cost);

	if(message == null) {
		throw new Exception("Service.INVALID_REQUEST");
		}
	
	
	return message;
	
	
}

@Override
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public ServiceCost getServiceCostDetails(String requestId) throws Exception {
	ServiceCost sc=new ServiceCost();
		sc=dao.get_service_cost(requestId);
		if(sc==null)
		{
			
			throw new Exception("Invalid RequestId");
			
		}
		return sc;
	}

@Override
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public List<ProblemTable> getAssistRequestDetails(ProviderLocation providerLocation) throws Exception {
	List<ProblemTable> pt = new ArrayList<ProblemTable>();
	pt=dao.getAssistRequestDetails(providerLocation);
	
	if(pt==null){
		throw new Exception("Problem.INVALID");
	}
	return pt;
}

@Override
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public List<AvailedServices> getPreAvailed_Seeker(String seekerId) throws Exception {

	List<AvailedServices> pt = new ArrayList<AvailedServices>();
	pt=dao.getPreAvailed_SeekerDetails(seekerId);
	
	if(pt==null){
		throw new Exception("Problem.INVALID");
	}
	return pt;
}

@Override
@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
public List<AvailedServices> getPreAvailed_Provider(String providerId) throws Exception {

List<AvailedServices> pt = new ArrayList<AvailedServices>();
pt=dao.getPreAvailed_ProviderDetails(providerId);

if(pt==null){
	throw new Exception("Problem.INVALID");
}
return pt;
}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public UserRating saveUserRating(UserRating rating) throws Exception {

		UserRating ur=new UserRating();
			ur=dao.set_userRating(rating);
			if(ur==null)
			{
				
				throw new Exception("Invalid Ratings");
				
			}
			return ur;
		}

@Override
@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
public SiteFeedBack saveFeedBack(SiteFeedBack feedBack) throws Exception {

	SiteFeedBack sfb;
	
	sfb=dao.addFeedback(feedBack);

	if(sfb == null) {
		throw new Exception("CANNOT ADD TO TABLE");
		}
	
	
	return sfb;
}


}

	



	
	
	
	
	
	
	
	
/*	@Transactional(readOnly = true)
	public AadharCard getAadhar(String aadharNumber) throws Exception {
		
		AadharCard aadharCard = dao.getAadhar(aadharNumber);
		
		if(aadharCard == null) {
			throw new Exception("Service.INVALID_AADHAR_NUMBER");
		}
		
		return aadharCard;
	}


	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public AadharCard updatePhoneNumber(AadharCard aadhar) throws Exception {
		AadharCard aadharCard = dao.updatePhoneNumber(aadhar);
		
		if(aadharCard == null) {
			throw new Exception("Service.INVALID_AADHAR_NUMBER");
		}
		
		return aadharCard;
	}

*/
	



