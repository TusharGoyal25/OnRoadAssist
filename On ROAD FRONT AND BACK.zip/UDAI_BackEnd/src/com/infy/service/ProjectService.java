package com.infy.service;

import java.util.List;

import com.infy.model.AvailedServices;
import com.infy.model.ProblemTable;
import com.infy.model.ProviderLocation;
import com.infy.model.ProviderStatus;
import com.infy.model.ServiceCost;
import com.infy.model.ServiceProvider;
import com.infy.model.ServiceSeeker;
import com.infy.model.SiteFeedBack;
import com.infy.model.UserRating;

public interface ProjectService {

	//public AadharCard getAadhar(String aadharNumber) throws Exception;

	//public AadharCard updatePhoneNumber(AadharCard aadhar) throws Exception;
	
	public String addSeeker(ServiceSeeker seeker) throws Exception;
	public ServiceSeeker seeker_login(ServiceSeeker seeker) throws Exception;
	public String addProvider(ServiceProvider provider) throws Exception;
	public ServiceProvider provider_login(ServiceProvider provider) throws Exception;
	public ServiceSeeker seeker_forget_password(ServiceSeeker seeker) throws Exception;
	public ServiceSeeker seeker_update_password(ServiceSeeker seeker) throws Exception;
	public ServiceProvider provider_forget_password(ServiceProvider provider) throws Exception;
	public ServiceProvider provider_update_password(ServiceProvider provider) throws Exception;
	public ServiceSeeker seeker_update_phoneno(ServiceSeeker seeker) throws Exception;
	 public  List<String> getCompanyName(String vehicleType) throws Exception;
	public List<String> getModelName(String companyName)throws Exception;
	public  List<String> get_problem_name(String vehicleType) throws Exception;

	public  String getEstimatedCost(String vehicleType,String probType) throws Exception;
	public Integer saveAssistRequest(ProblemTable table)throws Exception;
	public String setStatus(ProviderStatus ps) throws Exception;
	public List<ProblemTable> getAssistRequestDetails(ProviderLocation location) throws Exception;
	public ProblemTable provider_modify_cost(ProblemTable ps) throws Exception;
	
	public ServiceSeeker seeker_update_name(ServiceSeeker seeker) throws Exception ;
	public ServiceSeeker seeker_reset_password(ServiceSeeker seeker) throws Exception ;
	public ServiceProvider provider_reset_password(ServiceProvider provider) throws Exception;
	public String setProviderLocation(ProviderLocation l) throws Exception ;
	public ServiceProvider provider_update_name(ServiceProvider provider) throws Exception;
	public ServiceProvider provider_update_phoneno(ServiceProvider provider) throws Exception;
	List<String> getNearestProvider(ProblemTable table) throws Exception;
	public ServiceSeeker get_seeker_contact_details(String seekerid) throws Exception;
	public ProblemTable setRequestStatus(ProblemTable problemTable) throws Exception;
	public ProblemTable setProviderForService(ProblemTable problemTable) throws Exception;
	public ProblemTable getInProgressRequest(Integer requestId) throws Exception;
	public ServiceProvider get_provider_contact_details(String providerId) throws Exception;
	public ProviderLocation get_provider_location(String providerId) throws Exception;
	public String saveServiceCostDetails(ServiceCost cost) throws Exception;
	public ServiceCost getServiceCostDetails(String requestId) throws Exception;
	public List<AvailedServices> getPreAvailed_Seeker(String seekerId) throws Exception;
	public List<AvailedServices> getPreAvailed_Provider(String providerId) throws Exception;
	public UserRating saveUserRating(UserRating rating) throws Exception;
	public SiteFeedBack saveFeedBack(SiteFeedBack feedBack) throws Exception;
 
}
