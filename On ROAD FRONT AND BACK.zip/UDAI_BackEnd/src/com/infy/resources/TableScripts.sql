
DROP TABLE ServiceSeeker;
DROP TABLE ServiceProvider;
DROP TABLE vehicleData;
DROP TABLE ProblemCost;
DROP TABLE ProblemTable;
DROP TABLE ProviderStatus;
DROP TABLE ProviderLocation;
DROP TABLE ServiceCost;
DROP TABLE SiteFeedBack;

create table ServiceSeeker (
password varchar2(40) not null,
name varchar2(30) not null,
userId varchar2(40) PRIMARY KEY,
phoneNumber varchar2(11) not null,
question varchar2(125) not null,
answer varchar2(35) not null
);

create table ServiceProvider (
password varchar2(40) not null ,
name varchar2(30) not null,
userId varchar2(40) PRIMARY KEY,
phoneNumber varchar2(11) not null,
question varchar2(125) not null,
answer varchar2(35) not null,
rating varchar2(30) not null
);

create table VehicleData(
vehicleType varchar2(15) not null,
companyName varchar2(15) not null,
modelName varchar2(15) PRIMARY KEY

);

create table ProblemCost(
vehicleType varchar2(15) not null,
probType varchar2(50) ,
estimatedCost varchar2(50) 
);



create table ProblemTable(
requestId number primary key,
vproblem varchar2(50) not null,
probdescr varchar2(200) ,
vehnum varchar2(15) not null,
vtype varchar2(15) not null,
vmodel varchar2(15) not null ,
vmanuf varchar2(30) not null,
location varchar2(50) not null,
estimatedCost varchar2(15) not null ,
seekerId varchar2(30) not null,
status varchar2(10) not null,
providerId varchar2(30) not null,
reqDateTime varchar2(40) not null,
rating varchar2(30) not null
);


create table SiteFeedBack(
email varchar2(40) not null,
userName varchar2(40) not null,
easeOfAccess varchar2(300) not null,
bestFeature varchar2(300) not null,
rating varchar2(10) not null,
improve varchar2(300) not null,
recommendation varchar2(10) not null,
other varchar2(300) not null,
dateTime varchar2(40) not null);


create table ProviderStatus(
providerId varchar2(40)  primary key,
status varchar2(15) not null
);


create table ProviderLocation(
providerId varchar2(40) primary key,
location varchar2(50) not null
);

create table ServiceCost(
requestId varchar2(10) primary key,
providerId varchar2(40) not null,
seekerId varchar2(40) not null,
estimatedCost varchar2(10) not null,
distanceTravelled varchar2(10) not null,
travelCharge varchar2(10) not null,
totalCost varchar2(10) not null
);


insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Hyundai','Amaze');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Hyundai','i10');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Hyundai','i20');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Maruti Suzuki','Ertiga');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Maruti Suzuki','Brezza');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Maruti Suzuki','Baleno');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Maruti Suzuki','Dzire');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Maruti Suzuki','Omni');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Maruti Suzuki','Ciaz');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Tata','Harrier');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Tata','Safari');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Car','Tata','Nano');

insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','Hero','Splendor');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','Hero','Passion');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','Bajaj','Pulsar');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','TVS','Apache');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','KTM','Duke');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','Honda','Shine');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','Honda','Unicorn');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','Bajaj','Avenger');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','Hero','Deluxe');
insert into VehicleData (vehicleType ,companyName ,modelName) values ('Bike','Honda','Hornet');


insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Tyre Puncture(Tubeless)','250');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Tyre Puncture(Tube)','200');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Spare Tyre/Stepney Change','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Tyre Puncture','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Battery Jump start','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Towing','250');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Starting Trouble','300');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Emergency Petrol/Diesel','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Air fill -1 tyre','50');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Air fill -2 tyre','50');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Air fill -3 tyre','50');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Air fill -4 tyre','50');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Coolant Issue','400');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Diesel Pump -Airout','500');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Overheating','600');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Under Chassis Issue','500');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Wheel Jam','500');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Car','Other','100');

insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Tyre Puncture(Tube)','75');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Tyre Puncture(Tubeless)','100');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Battery jump start','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Towing','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Starting trouble','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Emergency Petrol','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Air fill','50');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Chain Issue','150');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Coolant Issue','250');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Accelerator Cable Issue','200');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Clutch Cable Issue','200');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Key Issue','200');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Overheating','300');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Wheel Jam','250');
insert into ProblemCost(vehicleType,probType,estimatedCost) values ('Bike','Other','100 ');

select * from ServiceSeeker;
select * from ServiceProvider;
select * from vehicleData;
select *from ProblemCost;
select * from ProblemTable;
select* from ProviderStatus;
select* from ProviderLocation;
select * from ServiceCost;
select * from SITEFEEDBACK;
